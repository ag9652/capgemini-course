package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.EmployeeDAO;
import com.entities.Employee;

@Service("employeeService")
public class EmployeeService implements EmployeeServiceImpl {
    private EmployeeDAO employeeDAO;
    
    public EmployeeDAO getEmployeeDAO() {
        return employeeDAO;
    }
    @Autowired
    public void setEmployeeDAO(EmployeeDAO employeeDAO) {
        this.employeeDAO = employeeDAO;
    }
    
    public void addEmployee(Employee employee) {
    	employeeDAO.addEmployee(employee);
    }
    
    public Employee fetchEmployeeById(int employeeId) {
        return employeeDAO.fetchEmployeeById(employeeId);
    }
    public void deleteEmployeeById(int employeeId) {
      employeeDAO.deleteEmployeeById(employeeId);
    }
    
    public List<Employee>getAllEmployeesInfo() {
        return employeeDAO.getAllEmployeesInfo();
    }
	public void updateEmployeeById(String newEmail, int employeeId) {
		employeeDAO.updateEmployeeEmailById(newEmail, employeeId);
		
	}
	
	
}
 


