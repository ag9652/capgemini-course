package com.client;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.entities.Employee;
import com.service.EmployeeService;
import com.service.EmployeeServiceImpl;
	public class Test {
		public static void main(String[] args) {
			ApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
			EmployeeService employeeService = ctx.getBean("employeeService", EmployeeService.class);
			createEmployee(employeeService);
			//getEmployeeById(employeeService);
			//fetchAllEmployeesInfo(employeeService);
			//employeeService.updateEmployeeEmailById("pavan@gmail.com", 1);
			//employeeService.deleteEmployeeById(1);
			}
		private static void fetchAllEmployeesInfo(EmployeeServiceImpl employeeService) {
			List<Employee> empList = employeeService.getAllEmployeesInfo();
			for (Employee employee : empList) {
				System.out.println(employee.getEmpid()+"\t"+employee.getEmpname()+"\t"+employee.getEmail()+"\t"+employee.getGender()+"\t"+employee.getSalary());
			}}
		private static void getEmployeeById(EmployeeServiceImpl employeeService) {
			Employee employee = employeeService.fetchEmployeeById(2);
			System.out.println(employee.getEmpid()+"\t"+employee.getEmpname()+"\t"+employee.getEmail()+"\t"+employee.getGender()+"\t"+employee.getSalary());
		}
		private static void createEmployee(EmployeeServiceImpl employeeService) {
			Employee employee = new Employee();
			employee.setEmail("gopal@gmail.com");
			employee.setEmpname("gopal");
			employee.setGender("Male");
			employee.setSalary(100000.00);	
			employeeService.addEmployee(employee);
		}

	}

