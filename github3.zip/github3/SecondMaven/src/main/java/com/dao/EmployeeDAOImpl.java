package com.dao;

import java.util.List;

import com.entities.Employee;

public interface EmployeeDAOImpl {
	void addEmployee(Employee employee);
    Employee fetchEmployeeById(int employeeId);
    void deleteEmployeeById(int employeeId);
    void updateEmployeeById(String newEmail,int employeeId);
    List<Employee> getAllEmployeesInfo();
}
