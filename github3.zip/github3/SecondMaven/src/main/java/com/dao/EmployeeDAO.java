package com.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.entities.Employee;
@Repository
public class EmployeeDAO implements EmployeeDAOImpl {

    @PersistenceContext // to give unique name , to create entity manager object automatically
    private EntityManager entityManager;
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    @Transactional
    public void addEmployee(Employee employee) {
        entityManager.persist(employee);
    }

    public Employee fetchEmployeeById(int employeeId) {

        return entityManager.find(Employee.class, employeeId);
    }

    public void deleteEmployeeById(int employeeId) {

        Employee employee = entityManager.find(Employee.class, employeeId);
        if (employee != null) {
            entityManager.remove(employee);
        }
    }

    @Transactional // used for all dml operations commit automatically
  
    public void updateEmployeeById(String newEmail, int employeeId) {
		Employee employee = entityManager.find(Employee.class, employeeId);
        if (employee != null) {
            employee.setEmail(newEmail);
            entityManager.merge(employee);
        }
    }

    public List<Employee> getAllEmployeesInfo() {
        Query query = entityManager.createQuery("From Employee");
    List<Employee> empList = query.getResultList();
        return empList;
    }

	public void updateEmployeeEmailById(String newEmail, int employeeId) {
		// TODO Auto-generated method stub
		
	}
	
	}



