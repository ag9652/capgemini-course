package com.cap;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.ModelAndView;

 

 

 

@Controller

 

 

 

public class HelloWorldController {

 

 

 

    @RequestMapping("/hello")  
    public ModelAndView helloWorld()  {
        String message="HELLLO  SPRING MVC HOW R U";
        return new ModelAndView("hellopage","message1",message); 
    }
    }
    