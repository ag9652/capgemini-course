

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

public class New implements ServletRequestListener {

    
    public New() {

    }

	
    public void requestDestroyed(ServletRequestEvent sre)  { 
System.out.println("project deployed");
    }

	
    public void requestInitialized(ServletRequestEvent sre)  { 
    	System.out.println("project deployed");

    }
	
}
