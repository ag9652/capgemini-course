

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Servlet1 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("txt/html");
		PrintWriter out= response.getWriter();
		String s= request.getParameter("a");
		HttpSession session =request.getSession();
		ServletContext context= request.getServletContext();
		if(s!=""&&s!=null)
		{
			session.setAttribute("name1",s);
			context.setAttribute("name2",s);
		}
		out.println("Request Object value : "+s);
		out.println("<br></br>");
		out.println("Session Object value : "+(String)session.getAttribute("name1"));
		out.println("<br></br>");
		out.println("Context Object value : "+(String)context.getAttribute("name2"));
		out.println("<br></br>");
	}

	

}
