package com.cap;
public class Employee {
    private int empId;
    private String empName;
    private int sal;
    private Address add;
    
    
    public int getEmpId() {
        return empId;
    }
    public void setEmpId(int empId) {
        this.empId = empId;
    }
    public String getEmpName() {
        return empName;
    }
    public void setEmpName(String empName) {
        this.empName = empName;
    }
    public int getSal() {
        return sal;
    }
    public void setSal(int sal) {
        this.sal = sal;
        
    }
    public Address getAdd() {
        return add;
    }
    public void setAdd(Address add) {
        this.add = add;
    }
    @Override
    public String toString() {
        return "Employee [empId=" + empId + ", empName=" + empName + ", sal=" + sal + "]";
    }
    public void display() {
        add.setHno("567");
        add.setColony("rajendra nagar");
        add.setCity("kkd");
        System.out.println(this.empId+" "+this.empName+" "+this.sal);
        System.out.println(this.add);
        
    }
    

 

 

 

}