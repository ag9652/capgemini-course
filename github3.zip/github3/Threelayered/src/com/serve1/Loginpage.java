package com.serve1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Loginpage extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String user=request.getParameter("uname");
		String password=request.getParameter("password");
		
		ServletConfig c= getServletConfig();
		String name= c.getInitParameter("g");
		System.out.println(name);
		
		
		ServletContext d= getServletContext();
		String url= d.getInitParameter("s");
		System.out.println(url);
		
			try {
				Class.forName(driver);
				Connection conn=DriverManager.getConnection(url,"gopal123","gopal123");
				psmt=conn.prepareStatement("select * from gmail where uname=? and password=?");
				psmt.setString(1, user);
				psmt.setString(2, password);
				

				ResultSet rs=psmt.executeQuery();
				
			
			if(rs.next())
			{
				RequestDispatcher rd=request.getRequestDispatcher("home.html");
				rd.include(request, response);
				out.println("NAME  :"+rs.getString("uname"));
				out.println("PASSWORD  :"+rs.getString("password"));
				out.println("CONTACT NUMBER  :"+rs.getString("contactnum"));
//				out.println("Date of birth  :"+rs.getString("dob"));
//				out.println("Gender  :"+rs.getString("gender"));

			}
			else
			{
				out.println("please register here");
				RequestDispatcher rd=request.getRequestDispatcher("registration.html");
				rd.include(request, response);


			}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}




