package com.cap;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

 

@Controller
public class Helloworldcontroller {

 

    @RequestMapping("/hello")

 

    public ModelAndView helloWorld() {
        String msg = "gopal";
        return new ModelAndView("HelloPage", "message", msg);
    }
}