package com.capg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.IDetailsDao;
import com.capg.entities.User;

/**
 * marking with @Service ,@Service is similar to @Component but used for service implementations
 *  Spring will create object of DetailsServiceImpl class and will keep in bean factory
 */
@Service//@Component
@Transactional
public class DetailsServiceImpl implements IDetailsService {


    /**
     * spring will inject with object of DetailsDaoImpl class because @Autowired is mentioned here
     */
    @Autowired
    private IDetailsDao dao;

    public IDetailsDao getDao(){
        return dao;
    }

    public void setDao(IDetailsDao dao){
        this.dao=dao;
    }

    public User findUserById(int id) {
       User user= dao.findUserById(id);
       return user;
    }

    public User createUser(User user) {
       // transaction opened by spring
         user= dao.createUser(user);
        //transaction closed by spring
        return user;
    }


    public User createUser(String name) {
        return dao.createUser(name);
    }
}











