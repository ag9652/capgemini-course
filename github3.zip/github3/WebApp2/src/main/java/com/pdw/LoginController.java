package com.pdw;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@RequestMapping("/login")
	public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse response)
	{
		String name=request.getParameter("name");
		String Password=request.getParameter("password");
		if(Password.equals("admin"))
		{
			String message="HELLO "+name;
			ModelAndView mv = new ModelAndView();
			mv.addObject("print",message);
			mv.setViewName("hellopage");
			return mv;
			
		}
		else
		{
			return new ModelAndView("errorpage","message","sorry,username and password is incorrect");
		}
	}

}
