import java.io.PrintWriter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Firstservlet extends HttpServlet {
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try {
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			String n=request.getParameter("username");
			out.print("Welcome"+n);
			Cookie ck = new Cookie("gmailid",n);
			response.addCookie(ck);
			out.println("<form action='servlet2'>");
			out.println("<input type='submit' value='yes'>");
			out.println("</form>");
			
			out.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
