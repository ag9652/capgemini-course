package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.InputValidation;
import com.capgemini.xyz.exception.InvalidAmount;
import com.capgemini.xyz.exception.InvalidDuration;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;

public class ExceuterMain {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		ILoanService loa = new LoanService();
		Customer cust = new Customer();
		Loan lus = new Loan();
		
		System.out.println("1) Register Customer\n 2) Exit");
		
		String userIn = sc.nextLine();

		switch(userIn){
			case "1":
				while(true) {
					try {
						System.out.println("Enter name");
						String name = sc.nextLine();
						System.out.println("Enter address");
						String addr = sc.nextLine();
						System.out.println("Enter gmail");
						String gmail = sc.nextLine();
						System.out.println("Enter mobile number");
						Long mobileNum = sc.nextLong();
						
						sc.nextLine();
						
						cust.setAddress(addr);
						cust.setCustName(name);
						cust.setEmail(gmail);
						cust.setMobile(mobileNum);
						loa.validateCustomer(cust);
						break;
					}
					catch(InputValidation a) {
						System.out.println(a.getMessage());
					}
					
					catch(Exception e) {
						System.out.println(e.getMessage());
					}
				}
				
				System.out.println(loa.insertCust(cust));
				
				System.out.println("Do you wish to apply for Loan?(Yes/No)");
				String loanIp = sc.nextLine();
				while(true) {
					if(loanIp.equals("Yes")) {
						
						System.out.println("Enter the loan amount");
						String amt = sc.nextLine();
						while(true) {
							try {
								loa.validateAmount(amt);
								break;
							}
							catch(InvalidAmount e) {
								System.out.println(e.getMessage());
								System.out.println("Enter again");
								amt = sc.nextLine();
								if(amt.equals("exit")) {
									break;
								}
							}
						}
						if(amt.equals("exit")) {
							break;
						}
						System.out.println("Enter the loan duration");
						String dur = sc.nextLine();
						while(true) {
							try {
								loa.validateDuration(dur);
								break;
							}
							catch(InvalidDuration e) {
								System.out.println(e.getMessage());
								System.out.println("Enter again");
								dur = sc.nextLine();
								if(dur.equals("exit")) {
									break;
								}
							}
						}
						if(dur.equals("exit")) {
							break;
						}
						double emi = loa.calculateEMI(Double.parseDouble(amt),Integer.parseInt(dur));
						System.out.println("For loan amount "+amt+" and "+dur+" Years duration.");
						System.out.println("Your EMI per month will be "+emi);
						System.out.println("Do you want to apply for loan now ?(Yes/No)");
						String loanApply = sc.nextLine();
						while(true) {
							if(loanApply.equals("Yes")) {
								lus.setCustId(cust.getCustId());
								lus.setDuration(Integer.parseInt(dur));
								lus.setLoanAmount(Double.parseDouble(amt));
								//lus.se
								
								loa.applyLoan(lus);
								break;
							}
							else if(loanApply.equals("No")) {
								System.out.println(cust);
								System.out.println("Thank You");
								System.exit(1);
								break;
							}
							else {
								System.out.println("Invalid input :[Type 'exit' for exit application]");
								loanApply = sc.nextLine();
								if(loanApply.equals("exit")) {
									System.out.println("Thank You");
									System.exit(1);
									//break;
								}
								
							}
						}	
								
					}
					else if(loanIp.equals("No")) {
						System.out.println(cust);
						System.exit(1);
						break;
					}
					else {
						System.out.println("Enter valid input");
						loanIp = sc.nextLine();
						if(loanIp.equals("exit")) {
							break;
						}
					}
				}
				break;
				
			case "2":
				System.out.println("Thank You");
				System.exit(1);
			default:
				System.out.println("invalid input");
		}
	}
}