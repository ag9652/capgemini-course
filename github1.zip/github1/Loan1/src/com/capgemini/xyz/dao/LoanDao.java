package com.capgemini.xyz.dao;

import java.util.HashMap;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class LoanDao implements ILoanDao{
	
//	customerEntry = new HashMap<Integer,Customer>();
	
	@Override
	public long applyLoan(Loan loan) {
		loanEntry.put((int) loan.getLoanID(), loan);
		return loan.getLoanID();
	}

	@Override
	public long insertCust(Customer cust) {
		//customerEntry = new HashMap<Integer,Customer>();
		int a =(int) cust.getCustId();
		System.out.println(a);
		customerEntry.put(a, cust);
		//System.out.println(cust.getCustId());
		return cust.getCustId();
	}

}