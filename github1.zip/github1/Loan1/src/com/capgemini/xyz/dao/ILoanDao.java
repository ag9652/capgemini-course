package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface ILoanDao {
	Map<Integer,Customer> customerEntry = new HashMap<Integer,Customer>();
	Map<Integer,Loan> loanEntry = new HashMap<Integer,Loan>();
	
	public long applyLoan(Loan loan);
	public long insertCust(Customer cust);
	
}