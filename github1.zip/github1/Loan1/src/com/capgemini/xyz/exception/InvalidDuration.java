package com.capgemini.xyz.exception;

public class InvalidDuration extends RuntimeException{
	public InvalidDuration(String message) {
		super(message);
	}
}