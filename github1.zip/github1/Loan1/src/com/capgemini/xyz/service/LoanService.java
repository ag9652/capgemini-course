package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.InputValidation;
import com.capgemini.xyz.exception.InvalidAmount;
import com.capgemini.xyz.exception.InvalidDuration;




public class LoanService implements ILoanService {
	
	
	ILoanDao dao = new LoanDao();
	@Override
	public long applyLoan(Loan loan) {
		long loanId = (long) (Math.random() * 100);
		loan.setLoanID(loanId); 
		//return dao.applyLoan(loan);
		return dao.applyLoan(loan);
	}

	@Override
	public Customer validateCustomer(Customer customer) {
		//add your validations here
		if(customer.getCustName().equals("")) {
			throw new InputValidation("Name cannot be empty");
		}
		return customer;
	}

	@Override
	public long insertCust(Customer cust) {
		// TODO Auto-generated method stub
		long custId = (long) (Math.random() * 100);
		cust.setCustId(custId);
		return dao.insertCust(cust);
	}

	@Override
	public double calculateEMI(double amount, int duration) {
		// TODO Auto-generated method stub
		double r = 9.5/100;
		double emi = (amount * r * (float)Math.pow(1 + r, duration))  
                / (float)(Math.pow(1 + r, duration) - 1);
		return emi;
		//return 0;
	}

	@Override
	public String validateAmount(String amount) {
		 for (char c : amount.toCharArray())
		    {
		        if (!Character.isDigit(c)) {
		        	throw new InvalidAmount("invalid amount number");
		        }
		    }
		return amount;
	}

	@Override
	public String validateDuration(String duration) {
		for (char c : duration.toCharArray())
	    {
	        if (!Character.isDigit(c)) {
	        	throw new InvalidDuration("invalid duration");
	        }
	    }
		return duration;
	}


}
