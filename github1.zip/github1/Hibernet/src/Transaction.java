
public class Transaction {

	public void commit() {
		// TODO Auto-generated method stub
		
	}

}
