
public class Session {

	public Transaction beginTransaction() {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(Employee emp) {
		// TODO Auto-generated method stub
		
	}

	public void close() {
		// TODO Auto-generated method stub
		
	}

}
