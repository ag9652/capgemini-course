
public class Configuration {

	public SessionFactory buildSessionFactory() {
		// TODO Auto-generated method stub
		return null;
	}

	public void configure() {
		// TODO Auto-generated method stub
		
	}

	public SessionFactory buildSessionFactory() {
		// TODO Auto-generated method stub
		return null;
	}

}
