public class Test {
public static void main(String args[]) {
    Configuration cfg=new Configuration();
   
    cfg.configure();
   
    SessionFactory factory=cfg.buildSessionFactory();
   
    Session session = factory.openSession();
   
    Transaction tran = session.beginTransaction();
   
    Employee emp=new Employee(123,"ruchi",120000);
    session.save(emp);
   
    tran.commit();
    session.close();
    factory.close();
}
}