package com.Junit;

public class Add {

	public int sum(int i, int j) {
		return i+j;
		
	}

}
