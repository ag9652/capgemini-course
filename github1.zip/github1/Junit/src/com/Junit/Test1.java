package com.Junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Test1 {
Add t = new Add();
int i=t.sum(122,20);
int j=142;

int i1=t.sum(122,20);
int j1=142;
@Test
public void testsum()
{
	System.out.println("sum is:"+i +"="+j);
	assertEquals(i,j);
}

@Test
public void testsum1()
{
	System.out.println("sum is:"+i1 +"="+j1);
	assertEquals(i1,j1);
}
}
