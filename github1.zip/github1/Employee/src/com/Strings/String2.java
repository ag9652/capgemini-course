package com.Strings;
import java.io.*;
import java.util.Scanner;
public class String2 {

public static void main(String args[]) 
{
	StringBuffer s = new StringBuffer();
	String str ="gopal siva durga";
	char ch[] = str.toCharArray();
	for(int i=0;i<str.length();i++)
	{
		if(i==0)
		{
			s=s.append(Character.toUpperCase(str.charAt(i)));
		}
		else if(ch[i]==' '&&ch[i+1]!=' ')
		{
			s.append(str.charAt(i));
			s=s.append(Character.toUpperCase(str.charAt(i+1)));
			i++;
		}
		else
		{
			s.append(str.charAt( i));
		}
	}
	System.out.println(s);
}
}
