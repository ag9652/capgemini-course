package com.Strings;
import java.util.Scanner;
public class String3 {

}
