package com.Strings;
import java.util.Scanner;
public class String1 {
static char b;
static int m1(String s,int a)
{
	b=s.charAt(a);
	return b;
}
public static void main(String args[])
{
	Scanner sc =  new Scanner( System.in);
	System.out.println("enter String");
	String s = sc.nextLine();
	System.out.println("enter index value ");
	int a= sc.nextInt();
	String1.m1(s, a);
	System.out.println(b);
}
}
