package com.capg.corejava;
 
   class F {
	 int a;
	 public void s() {
		 this.a = ++a;
		 System.out.println("after the increment"+a);
	 }
}
class Final extends F{
	final public void s() {
		  super.a = --a;
		 System.out.println("after the decrement"+a);
	 }
public static void main(String args[]) {
	Final t= new Final();
	t.s();
	F a=new F();
	a.s();
	
}
}