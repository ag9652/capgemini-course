package com.capg.corejava;

  class I {
	public void m1()
	 {
		 System.out.println("G class m1 method");
	 }
	 public void m2()
	 {
		 System.out.println("G class m2 method");
	 }
  }
	 class H extends I
	 {
	 public void m3()
	 {
		 System.out.println("H class m3 method");
	 }
	 public void m4()
	 {
		 System.out.println("H class m4 method");
	 }
	 }
	 public class G extends I
	 {
		 
	 public void m5()
	 {
		 System.out.println("H class m5 method");
	 }
	 public void m6()
	 {
		 System.out.println("H class m6 method");
	 }
	 
	 public static void main(String args[])
	 {
		 G t=new G();
		 H q=new H();
		 t.m1();
		 t.m2();
		 q.m3();
		 q.m4();
		 t.m5();
		 t.m6();
	 }
}
