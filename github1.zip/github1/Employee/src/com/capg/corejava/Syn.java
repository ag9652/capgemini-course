package com.capg.corejava;

public class Syn {

}
