package com.capg.corejava;
import java.util.Scanner;

class U extends Exception{
	
	private String Password ;
	private String Username;
	public U(String Username, String Password) {
		this.Username=Username;
		this.Password=Password;
	}
	public String toString() {
		return "you are validated to capgemini";
	}
 public static class User{
	public static void  validation (String Username,String Password) throws U{
		if ( Username.equals(Password)) {
			throw new U( Username,Password);
		}
		else 
		{
			System.out.println("not valid");
		}
	}
	public void main(String args[]) throws U
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter username");
		String Username = sc.nextLine();
		System.out.println("enter password");
		String Password = sc.nextLine();
		User.validation(Username,Password);
		System.out.println("program ends");
	}
}
}
