package com.capg.corejava;

 class C{
	
 public void m1()
 {
	 System.out.println("A class m1 method");
 }
 public void m2()
 {
	 System.out.println("A class m2 method");
 }
 
}
 class B extends C {
	 public void m3()
	 {
		 System.out.println("B class m3 method");
	 }
	 public void m4()
	 {
		 System.out.println("B class m4 method");
	 }
 }
	 public  class A extends B{
		 public void add()
		 {
			 int a=12;
			 int b=13;
			 System.out.println("addition of two numbers "+(a+b));
		 }
	 
	 public static void main(String args[])
	 {
		 A t=new A();
		 t.add();
		 t.m1();
		 t.m2();
		 t.m3();
		 t.m4();
		 
	 }
	 }
 
