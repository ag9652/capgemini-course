package com.capg.corejava;


public class Details {
	private int eid=123;
	private String ename="rahul";
	private int esal=240000;
	private int epin=5234;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	public int getEpin() {
		return epin;
	}
	public void setEpin(int epin) {
		this.epin = epin;
	}
	
}
