package com.capg.corejava;
import java.util.Scanner;

public class Employee {
public Employee(int i, String string, int j) {
	}

public static void main(String args[])
{
	String eName="";
	Scanner sc=new Scanner(System.in);
	System.out.println("enter your empId");
	int empId=sc.nextInt();
	System.out.println("enter your empName");
	 eName=sc.next();
	 eName+=sc.nextLine();
	System.out.println("enter your empSal");
	int empSal=sc.nextInt();
	 
	System.out.println(empId+" "+eName+" "+empSal);
	sc.close();

}
}
