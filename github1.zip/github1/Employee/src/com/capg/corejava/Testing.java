package com.capg.corejava;

 class Dh {
	 static void add() {
		 System.out.println("default method");
	 }
	 static void add(int a,int b) {
		 System.out.println("addition of two numbers(int) is:"+(a+b));
	 }
	 static void add(float a,float b) {
		 System.out.println("addition of two numbers(float,float) is:"+(a+b));
	 }
	 static void add(int a,float b) {
		 System.out.println("addition of two numbers(int,float) is:"+(a+b));
	 }
	 static void add(float a,int b) {
		 System.out.println("addition of two numbers(flaot,int) is:"+(a+b));
	 }
}
class Overload{
	public static void main(String args[])
	{
		 Dh .add();
		 Dh .add(2,9);
		 Dh .add(2.2f,9.0f);
		 Dh .add(2,9.0f);
		 Dh .add(2.4f,9);
	}
}