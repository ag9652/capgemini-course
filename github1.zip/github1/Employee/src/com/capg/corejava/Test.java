package com.capg.corejava;

public class Test {
	public void m1() {
		System.out.println("THIS IS TRHE TEST CLASS INSTANCE METHOD");
		
	}
	public static void m2() {
		System.out.println("THIS IS THE TEST CLASS OF STATIC METHOD");
	}
	public int add()
	{
		int a=10;
		int b=10;
		return a+b;
				
	}
	public int sub(int a, int b)
	{
		return a-b;
	}
	public static void main(String args[])
	{
		Test.m2();
		Test t=new Test();
		t.m1();
		int sum=t.add();
		int minus=t.sub(12,13);
		System.out.println(sum+" "+minus);
				
	}
}
