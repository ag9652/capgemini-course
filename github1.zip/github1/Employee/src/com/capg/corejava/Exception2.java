package com.capg.corejava;

import java.lang.reflect.Array;

public class Exception2 {
public static void main(String args[])
{
	try 
	{
		int a1=10;
		int b=0;
		int c= a1/b;
	}
	catch(ArithmeticException ae) {
		System.out.println("dont enter zero as denominator");
		System.out.println(ae);
		ae.printStackTrace();
		System.out.println(ae.getMessage());
	}
	try {
		int a[] = new int[5];
		a[0]=1;
		a[4]=5;
	}
	catch(ArrayIndexOutOfBoundsException ae)
	{
		System.out.println("array index is maximum");
	}
	System.out.println("remaining");

}
}
