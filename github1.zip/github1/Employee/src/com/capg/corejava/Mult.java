package com.capg.corejava;

interface Gopal {
	static int add()
	{
		int a=10;
		int b=10;
		return a+b;
	}

}
interface Pavan{
 static int sub()
	{
		int a=10;
		int b=10;
		 return a-b;
	}
}
public class Mult implements Gopal,Pavan
{
	public void sub() {
		System.out.println("subtration");
	}
	public void add() {
		System.out.println("addition");
	}
	public static void main(String args[])
	{
	Mult t=new Mult();
	t.add();
	t.sub();
	Gopal.add();
	Pavan.sub();
	}
}
