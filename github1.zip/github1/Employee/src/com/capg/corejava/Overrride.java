package com.capg.corejava;

 class S {
	public void hi() {
		System.out.println("i am dude");
	}
	public void hello() {
		System.out.println("i am person");
	}
}
class Override extends S{
	public void hello() {
		System.out.println("i am what"
				+ ""
				+ ""
				+ ""
				+ "");
	}
	public void you() {
		System.out.println("i am guy");
	}
	public static void main(String args[]) {
		Override t=new Override();
		t.hi();
		t.hello();
		t.you();
	}
	
}
