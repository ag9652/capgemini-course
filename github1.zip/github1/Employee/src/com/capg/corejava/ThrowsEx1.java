package com.capg.corejava;
 class Cal {
	public  void div(String a,String b) throws Exception {
		int c = Integer.parseInt(a)/Integer.parseInt(a);
		System.out.println(c);
	}

}
public class ThrowsEx1{
	public static void main(String args[])  {
		Cal o= new Cal();
		try {
			o.div("10","0");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}