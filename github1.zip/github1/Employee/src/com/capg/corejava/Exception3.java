package com.capg.corejava;

public class Exception3 {
	public static void main(String args[])
	{
		try 
		{
			int a[] = new int[5];
			a[4]=30/2;
			String s="ibm";
			int x= Integer.parseInt(s);
			System.out.println(s.length());
			System.out.println("no error "+ a[4]+""+x);
		}
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("please eneter a valid index");
		}
		catch(ArithmeticException ae) {
			System.out.println("dont enter zero as denominator");
		}
		catch(NumberFormatException ae) {
			System.out.println("we cant convert string to number");
		}
		catch(Exception e) {
			System.out.println("unable to find length of the string ");
		}
		finally {
			System.out.println("execute every time for closing connection");
		}
		System.out.println("execte every code");
}

}
