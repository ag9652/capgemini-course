package com.capg.corejava;

public class Buffer {
	
	public static void main(String args[]) {
		String st="gopal siva durga";
		StringBuffer sb = new StringBuffer("ibm");
		StringBuffer sb1 = new StringBuffer("ibm");
		String str=sb.toString();
		String str1=sb1.toString();
		System.out.println(sb.equals(sb1));
		System.out.println(sb==sb1);
		System.out.println(sb);
		sb.append("banglore");
		System.out.println(sb);
		String s= new String("gopal");
		String s1= new String("gopal");
		System.out.println(s==s1);
		System.out.println(st.toLowerCase());
		System.out.println(st.toUpperCase());
		System.out.println(str.compareToIgnoreCase(str1));
		System.out.println(st.indexOf('a'));
		System.out.println(st.trim());
		System.out.println(st.length());
		System.out.println(st.codePointAt(1));
		System.out.println(st.codePointBefore(3 ));
	}
	
}

