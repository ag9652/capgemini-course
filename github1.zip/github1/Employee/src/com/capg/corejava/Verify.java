package com.capg.corejava;

public class Verify {
public static void main(String args[]) {
	Details a =new Details();
	System.out.println(a.getEid());
	System.out.println(a.getEname());
	System.out.println(a.getEsal());
	System.out.println(a.getEpin());
}
}
