package com.capg.corejava;

public class Employee1
{
	public static void main(String args[])
	{
		String empName=args[0];
		int empId=Integer.parseInt(args[1]);
	    int empSal=Integer.parseInt(args[2]);
				System.out.println(empId+" "+empName+" "+empSal);
	}
	
}

