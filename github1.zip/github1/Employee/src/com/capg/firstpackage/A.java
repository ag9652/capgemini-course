package com.capg.firstpackage;

 class Hi {
	public void m1()
	{
		System.out.println("it is inside the package");
	}
	public void m2()
	{
		System.out.println("it is what");
	}
}
public class A extends Hi {
	 public static void main(String args[]) {
		 A t=new A();
		 t.m1();
		 t.m2();
		 
	 }
}