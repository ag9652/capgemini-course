package com.capg.secondpackage;
import com.capg.firstpackage.*;
public class B extends A {
	public static void main(String args[]) {
		B s=new B();
		s.m1();
		s.m2();
	}
}
