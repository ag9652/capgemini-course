package com.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class Deserialization {
public static void main(String args[]) throws IOException,ClassNotFoundException
{
	FileInputStream fis = new FileInputStream( "capgemini.txt");
	ObjectInputStream ois = new ObjectInputStream( fis);
	Student st = (Student)ois.readObject();
	System.out.println(st.getSno());
	System.out.println(st.getName());
	
	ois.close();
}
}