package com.test;
import java.io.*;


class Student implements Serializable{
	private int sno;
	private String name;


public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
	public class Sereialization{
public static void main(String args[]) throws IOException{
	Student student=new Student();
	student.setSno(1011);
	student.setName("gopal");
	
	FileOutputStream fos=new FileOutputStream( "capgemini.txt");
	ObjectOutputStream oos=new ObjectOutputStream(fos);
	oos.writeObject(student);
	System.out.println("success");
}
}