package com.test;
import java.util.Scanner;
public class Myexception {
		public static void main(String args[]) 
		{
			Scanner sc = new Scanner(System.in);

			System.out.println("enter first number of the divison");
			int fnum= sc.nextInt();
			System.out.println("enter second number of the divison");
			int snum= sc.nextInt();
			try {
				int div = fnum/snum;
				System.out.println("divison of two numbers is "+div);
			}
			catch(Exception e)
			{
				System.out.println("no zero in denominator");
			}
			
			System.out.println("next code is execute");
		}
}
