package com.Collections;

import java.util.Vector;

public class Vector1 {
	public static void main(String[] args) {
		
		
		Vector v=new  Vector();
		v.add("rao");
		v.add("gopal");
		v.add("rao");
		System.out.println(v);
		v.addElement('c');
		System.out.println(v);
		v.remove(0);
		System.out.println(v);
		System.out.println(v.size());
		System.out.println(v.capacity());
		System.out.println(v);
		System.out.println("list :"+v);
}
}