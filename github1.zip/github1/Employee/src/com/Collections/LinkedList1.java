package com.Collections;

import java.util.LinkedList;

public class LinkedList1 {
	public static void main(String[] args) {
		
	
LinkedList ll=new LinkedList();
ll.add("rao");
ll.add("gopal");
ll.add("rao");
System.out.println(ll);
ll.addLast("garu");
System.out.println(ll);
ll.addFirst("kalaposana");
System.out.println(ll);
ll.getFirst();
System.out.println(ll.getFirst());
System.out.println(ll.getLast());
ll.removeFirst();
System.out.println(ll);
ll.removeLast();
System.out.println( ll);
}
}