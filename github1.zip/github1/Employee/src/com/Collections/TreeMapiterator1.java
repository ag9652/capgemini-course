package com.Collections;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;


public class TreeMapiterator1 {
	public static void main(String[] args) {
		
	
	TreeMap tr=new TreeMap();
	tr.put('c',1);
	tr.put('d',13);
	tr.put('f',12);
	tr.put('e',11);
//System.out.println(tr);
tr.entrySet();
Set s=tr.entrySet();
Iterator itr = s.iterator();
while(itr.hasNext())
{
	Entry e=(Entry) itr.next();
	System.out.println(e.getKey()+" "+e.getValue());
}
}
}
