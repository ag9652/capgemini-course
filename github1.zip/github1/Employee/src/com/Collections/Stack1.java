package com.Collections;

import java.util.Stack;

public class Stack1 {
public static void main(String[] args) {
		
		
		Stack s=new  Stack();
		s.add("rao");
		s.add("gopal");
		s.add("shankar");
		System.out.println(s);
		System.out.println(s.search("gopal"));
		System.out.println(s.push("siva"));
		
		System.out.println(s);
		System.out.println(s.pop());
		System.out.println(s);
		System.out.println(s.empty());
		System.out.println(s.peek());
}
}