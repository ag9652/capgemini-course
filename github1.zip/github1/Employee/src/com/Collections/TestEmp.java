package com.Collections;
import java.util.Comparator;
import java.util.TreeSet;
class Employee implements Comparable {
String name;
int eid;
Employee(String name,int eid)
{
	this.name=name;
	this.eid=eid;
}
public String toString()
{
	return name+"--"+eid;
}
public int compareTo(Object obj1)
{
	int eid1 = this.eid;
	Employee e = (Employee)obj1;
	int eid2=e.eid;
	//System.out.println(eid1+" "+eid2);
	if(eid1<eid2)
	{
		return -1;
	}
	else if(eid1>eid2)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

 }
public class TestEmp{
	public static void main(String[] args) {
		Employee e1=new Employee("gopal",123);
		Employee e2=new Employee("rahul",124);
		Employee e3=new Employee("anand",125);
		Employee e4=new Employee("ravi",126);
 TreeSet t = new TreeSet();
 t.add(e1);
 t.add(e2);
 t.add(e3);
 t.add(e4);
 System.out.println(t);
 
 TreeSet t1 = new TreeSet(new Mycomparator3());
t1.add(e1);
t1.add(e2);
t1.add(e3);
t1.add(e4);
System.out.println(t1);
	}
	}
class Mycomparator3 implements Comparator
{
	public int compare(Object obj1,Object obj2)
	{
		Employee e1 = (Employee)obj1;
		Employee e2 = (Employee)obj2;
		String s1=e1.name;
		String s2=e2.name;
		return s1.compareTo(s2);
	}
}