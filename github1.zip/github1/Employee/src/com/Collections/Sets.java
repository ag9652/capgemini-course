package com.Collections;
import java.util.*;
public class Sets {
public static void main(String[] args) {
	//TreeSet ts = new TreeSet();
	//HashSet ts = new HashSet();
	LinkedHashSet ts = new LinkedHashSet();
	ts.add(10);
	ts.add(1);
	ts.add(5);
	ts.add(7);
	System.out.println(ts);
}
}
