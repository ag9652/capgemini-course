package com.Collections;

public class Emplo {

	
	private int eid;
	private String ename;
	public Emplo(int eid,String ename)
	{
	super();
	this.eid=eid;
	this.ename=ename;
}
	@Override
	public String toString() {
		return "emp id : "+eid+ ", emp name : "+ename;
	}
	
}
