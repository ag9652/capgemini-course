package com.Collections;

import java.util.TreeSet;
import java.util.Comparator;
import java.util.*;

public class Treeset1 {
	public static void main(String[] args) {
		TreeSet ts = new TreeSet(new Mycomparator());
		//HashSet ts = new HashSet();
		//LinkedHashSet ts = new LinkedHashSet();
		ts.add("a");
		ts.add("c");
		ts.add("b");
		//ts.add(7);
		System.out.println(ts);
	}
}
 class Mycomparator implements Comparator
	{
		public int compare(Object o1,Object o2)
		{
			String i1= (String) o1;
			String i2= (String) o2;
			/*if(i1<i2)
			{
				return +1000;
			}
			else if(i1>12)
			{
				return -10000;
			}
			else
			{
				return 0;
			}*/
			//return -i1.compareTo(i2);
		return i2.compareTo(i1);	
		}
	}

