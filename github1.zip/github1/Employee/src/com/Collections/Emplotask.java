package com.Collections;
import java.util.*;
public class Emplotask {
public static void main(String[] args) {
		Emplo e = new Emplo(123,"rahul");
		Emplo e1 = new Emplo(12,"siva");
		Emplo e2 = new Emplo(13,"gopal");
		Emplo e3 = new Emplo(23,"durga");
	
	ArrayList al=new ArrayList();
	al.add(e);
	al.add(e1);
	al.add(e2);
	al.add(e3);
	System.out.println(al);
}

}
