package com.Collections;
import java.util.*;
public class Enumeration1
{

public static void main(String[] args) 
 {
	Vector day =new Vector();
	day.add("SUNDAY");
	day.add("MONDAY");
	day.add("TUESDAY");
	day.add("WEDNESDAY");
	day.add("THURSDAY");
	day.add("FRIDAY");
	day.add("SATURDAY");

	System.out.println(day);
	Enumeration days = day.elements();
	while (days.hasMoreElements())
	{
		System.out.println(days.nextElement());
	}
 }
}

