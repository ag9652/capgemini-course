package com.Collections;
class Number
{
	public int n;
	boolean value= false;
	synchronized  void Even(int n)
	{
		if(!value)
		{
			try {
				wait();
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
			this.n=n;
			System.out.println(n);
			value=false;
			notify();
		
		
	}
	synchronized  void Odd(int n)
	{
		if(value)
		{
			try {
				wait();
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
			this.n=n;
			System.out.println(n);
			value=true;
			notify();
		
		
	}
}
class Odd implements Runnable
{
	Number num;
	Odd(Number num)
	{
		this.num=num;
		new Thread(this,"odd").start();
	}
	public void run()
	{
		for(int i=1;i<=100;i=i+2)
		{
			num.Odd(i);
		}
	}
	
}
class Even implements Runnable
{
	Number num;
	Even(Number num)
	{
		this.num=num;
		new Thread(this,"even").start();
	}
	public void run()
	{
		for(int i=2;i<=100;i=i+2)
		{
			num.Even(i);
		}
	}
	
}
public class Interthread {
public static void main(String[] args) {
	Number number =  new Number();
	Even e = new Even(number);
	Odd d= new Odd(number);
}
}
