package com.Collections;
import java.util.*;
import java.util.Comparator;
public class TreeMap1 {
	public static void main(String[] args) {
		TreeMap tr=new TreeMap(new MyComp());
		tr.put('c',1);
		tr.put('d',13);
		tr.put('f',12);
		tr.put('e',11);
	System.out.println(tr);
	}
}
class MyComp implements Comparator
{
	public int compare(Object arg0,Object arg1)
	{
		String s1=arg0.toString();
		String s2=arg1.toString();
		return s2.compareTo(s1);
	}
}
