package com.Collections;

public class CompareTo1 {
public static void main(String[] args) {
	System.out.println("A".compareTo("Z"));
	System.out.println("Z".compareTo("K"));
	System.out.println("A".compareTo("1M"));

}
}
