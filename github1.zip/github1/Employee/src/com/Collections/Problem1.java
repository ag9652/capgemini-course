package com.Collections;
import java.util.Map.Entry;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

import javax.swing.text.html.parser.Entity;
class Problem2 
{ 
	String accounttype;
	String name;
	String balance;
	int bal;
	public Problem2(String string, int bal, String name) {
		
super();
this.accounttype=accounttype;
this.balance=balance;
this.name=name;

	}
	

	public String getAccounttype() {
		return accounttype;
	}




	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getBalance() {
		return balance;
	}




	public void setBalance(String balance) {
		this.balance = balance;
	}




	



	public int getBal() {
		return bal;
	}




	public void setBal(int bal) {
		this.bal = bal;
	}




	
	
}	

public class Problem1 
{
	public static void main(String[] args)
	{
		Account a=new Account("prepaid",200,"hi");
		Account a1=new Account("prepaid",455,"hello");

		Account a2=new Account("prepaid",456,"how");

		Account a3=new Account("prepaid",523,"you");
		HashMap<String,Account> hm = new HashMap<String,Account>();

		hm.put("935123565", a);
		hm.put("935123565", a1);
		hm.put("935123565", a2);
		hm.put("935123565", a3);

		
		Scanner sc=new Scanner(System.in);
		System.out.println("select u r option");
		System.out.println("1.display account info");
		System.out.println("2.recharge account");
		int bal=sc.nextInt();
		switch(bal)
		{
		case 1:
			System.out.println("enter the mobile number");
			String mobile=sc.next();
			Problem2 ac= (Problem) hm.get(mobile);
			System.out.println(ac);
		case 2:
			System.out.println("enter mobile number");
			String mn1 = sc.next();
			Problem2 ac1 = (Problem) hm.get(mn1);
		    String balance = ac1.getBalance();
			String  name= ac1.getName();
			System.out.println("enter the amount");
			int newbalance= sc.nextInt();
			int oldbal= Integer.parseInt(balance);
			int updatebal =  newbalance+oldbal;
			System.out.println("hello"+name+"u r updated balance"+updatebal);
			
			
			
		}
	}
}

