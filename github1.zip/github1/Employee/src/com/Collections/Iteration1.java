package com.Collections;

import java.util.Iterator;
import java.util.Vector;

public class Iteration1 {

public static void main(String[] args) {
	Vector day =new Vector();
	day.add("SUNDAY");
	day.add("MONDAY");
	day.add("TUESDAY");
	day.add("WEDNESDAY");
	day.add("THURSDAY");
	day.add("FRIDAY");
	day.add("SATURDAY");

	System.out.println(day);
	Iterator itr1=day.iterator();
	while(itr1.hasNext())
	{
		String name = (String) itr1.next();
		if(name.equals( "MONDAY"))
		{
			itr1.remove();
		}
		else {
			System.out.println(name);
		}
	}
}
}