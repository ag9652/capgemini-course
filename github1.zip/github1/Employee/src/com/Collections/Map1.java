package com.Collections;
import java.util.*;
public class Map1 {
public static void main(String[] args) {
	LinkedHashMap m=new LinkedHashMap();
	m.put("gopal", 123);
	m.put("pavan", 525);
	m.put("aravind",45);
	m.put("dharma", 854);
	System.out.println(m);
	TreeMap a=new TreeMap();
	a.put("pav2an", 52325);
	a.put("arav5ind",425);
	a.put("dhar3ma", 8254);
	a.putAll(m);
	System.out.println(a.get("gopal"));
	
}
}
