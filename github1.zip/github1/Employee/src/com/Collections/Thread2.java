package com.Collections;

class method2 extends Thread
{

	@Override
	public void run() 
	{
		for(int i=0;i<10;i++)
		{
			System.out.println("user thread");
		}	
	}
}

public class Thread2 
{
	public static void main(String[] args) throws InterruptedException 
	{
		method2 q=new method2();
		q.start();
		q.join();
		for( int i=0;i<10;i++)
			{
				//Thread.currentThread().setName("ram");
				//Thread.currentThread().setPriority(9);
				System.out.println("mainthread");
			}
 	}
}
