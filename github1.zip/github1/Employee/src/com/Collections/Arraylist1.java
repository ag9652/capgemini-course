package com.Collections;
import java.util.*;
public class Arraylist1 {
	public static void main(String[] args) {
		
	
      ArrayList al=new ArrayList();
      al.add("rao");
      al.add("gopal");
      al.add("rao");
     // System.out.println(al);
      ArrayList al1=new ArrayList();
      al1.add('x');
      al1.add(123);
      al1.add("rao");
      al1.add(true);
      al1.addAll( al);
//System.out.println(al1);
//al1.removeAll(al);
//System.out.println(al1);
//al1.clear();
//System.out.println(al1);
//al1.clone();
//System.out.println(al1);
     // al1.contains(al1);
     // System.out.println(al1);
      //al.containsAll(al1);
      //System.out.println(al);
      //al.ensureCapacity(5);
      //System.out.println(al);
      
}

}