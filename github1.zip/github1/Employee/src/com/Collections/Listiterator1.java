package com.Collections;

import java.util.ArrayList;
import java.util.ListIterator;

public class Listiterator1 {
public static void main(String[] args) {
	ArrayList<String> ar = new ArrayList<String>();
	ar.add("ab");
	ar.add("bc");
	ar.add("cd");
	ar.add("de");
	System.out.println(ar);
	ListIterator litr = ar.listIterator();
	while(litr.hasNext())
	{
		System.out.println(litr.next()+"");
	}
	while(litr.hasPrevious())
	{
		String val = (String)litr.previous();
		if(val.equals("cd"))
		{
			litr.set("capgemini");
			System.out.println(litr.next());
			litr.previous();
		}
		else
		{
			System.out.println(val);
		}
	}
}
}
