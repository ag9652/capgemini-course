package com.Threads;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConnHM1 extends Thread{
	static ConcurrentHashMap<Integer,String> chm = new ConcurrentHashMap<>();
	public void run()
	{
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException ie)
		{
			ie.printStackTrace();
			System.out.println("chid thread got chance");
			chm.put(45,"Capgemini");
		}
	
	}
public static void main(String[] args)  throws InterruptedException{
	chm.put(4125, "hi");
	chm.put(415, "hhelo");
	chm.put(412, "people");
	ConnHM1 c= new ConnHM1();
	c.start();
	Set s=chm.keySet();
Iterator itr = s.iterator();
while(itr.hasNext())
{
	Integer i = (Integer) itr.next();
	System.out.println("main thread iterating.....");
	System.out.println("current key is ....:"+i+" and value :"+chm.get(i));
	Thread.sleep(1000);
	System.out.println(chm);
}
}
}
