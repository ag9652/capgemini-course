package com.Threads;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayList2 extends Thread{
	static CopyOnWriteArrayList cal = new CopyOnWriteArrayList();
	public void run()
	{
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException ie)
		{
			ie.printStackTrace();
			System.out.println("chid thread got chance");
			cal.add("a");
}
	
	}
public static void main(String[] args)  throws InterruptedException{
	cal.add("b");
	cal.add("c");
	CopyOnWriteArrayList2 c= new CopyOnWriteArrayList2();
	c.start();
Iterator itr = cal.iterator();
while(itr.hasNext())
{
	String values = (String) itr.next();
	System.out.println("main thread iterating cal values .....:"+values);
	Thread.sleep(1000);
	System.out.println(cal);
}
}
}
