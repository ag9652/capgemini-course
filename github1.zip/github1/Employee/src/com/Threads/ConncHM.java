package com.Threads;

import java.util.HashMap;

public class ConncHM {
public static void main(String[] args) {
	HashMap<Object, Object> hm=new HashMap<>();
	hm.put(89,"gopas");
	hm.put(85,"gopaaesf");
	hm.put(81,"gopadf");
	hm.putIfAbsent(45," bghj");
	hm.remove(81);
	hm.replace(45,"gopal");
	System.out.println(hm);
}
}
