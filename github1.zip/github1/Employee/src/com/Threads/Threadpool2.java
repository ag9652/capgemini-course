package com.Threads;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Threadpool2 {
public static void main(String[] args) {
	ScheduledExecutorService service = Executors.newScheduledThreadPool(0);
	service.schedule(new Task3(),10,TimeUnit.SECONDS);
	service.scheduleAtFixedRate(new Task(),15,10, TimeUnit.SECONDS);
	service.scheduleWithFixedDelay( new Task(),15, 10,TimeUnit.SECONDS );
}
}
class Task3 implements  Runnable
{
	public void run()
	{
		System.out.println("Thread name :"+Thread.currentThread().getName());

	}
}