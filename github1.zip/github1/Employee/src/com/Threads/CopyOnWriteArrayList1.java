package com.Threads;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayList1 {
public static void main(String[] args) {
	CopyOnWriteArrayList<Object> al = new CopyOnWriteArrayList<>();
	al.add("hi");
	al.add("hello");
	al.add("u");
	al.addIfAbsent("hello");
	System.out.println(al);
	ArrayList<Object> al1 = new ArrayList<>();
	al1.add("gopal");
	al.addAllAbsent(al1);
System.out.println(al);
}
}
