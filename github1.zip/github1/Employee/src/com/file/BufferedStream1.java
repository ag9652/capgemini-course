package com.file;
import java.io.*;
public class BufferedStream1 {
public static void main(String args[]) throws IOException
{
	String filepath ="sl.txt";
	FileOutputStream fos = new FileOutputStream(filepath);
	BufferedOutputStream bos = new BufferedOutputStream( fos);
	String s="oracle.com";
	byte [] b = s.getBytes();
	bos.write( b);
	bos.flush();
	
	FileInputStream fis = new FileInputStream(filepath);
	BufferedInputStream bis = new BufferedInputStream( fis);
	int i;
	while((i=bis.read())!=-1)
	{
		System.out.println((char)i);
	}
}
}
