package com.file;
import java.io.*;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class Login {
public static void main(String args[]) throws IOException
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Username");
	String Username=sc.next();
	System.out.println("Password");
	String Password=sc.next();

	FileReader fr=new FileReader("pw1.txt");
	BufferedReader br=new BufferedReader(fr);
	String s=br.readLine();
	while(s !=null)
	{
		if(Username.equals(s))
		{
			s= br.readLine();
					if(Password.equals(s))
					{
						
						System.out.println("login Success");
					}
				}
				else
				{
					System.out.println("login fail");
				}
				
					System.out.println(s);
					s= br.readLine();
					
				}
		br.close();
	}

}