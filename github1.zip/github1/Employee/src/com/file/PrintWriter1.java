package com.file;
import java.io.*;
public class PrintWriter1 {
	public static void main(String args[]) throws IOException
	{
		FileWriter fw = new FileWriter("pw1.txt");
		PrintWriter out = new PrintWriter(fw);

		//out.println(1000);
		out.println("gopal");
		out.println("abc");
		out.println("gopal1");
		out.println("abc1");
		//out.println(true);
		out.close();


		fw.close();


	}
}
