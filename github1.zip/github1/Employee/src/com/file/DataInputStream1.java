package com.file;
import java.io.*;
public class DataInputStream1 {
	public static void main(String args[]) throws IOException
	{
		FileOutputStream fs =new  FileOutputStream("hello.txt");
		DataOutputStream dos = new DataOutputStream( fs);
		dos.writeInt(10);
		dos.writeUTF( "gopal");
		DataInputStream dis = new DataInputStream(new FileInputStream("hello.txt"));
		System.out.println("Int : "+dis.readInt());
		System.out.println("String : "+dis.readUTF());
	}

}
