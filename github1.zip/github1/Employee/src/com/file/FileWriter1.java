package com.file;
import java.io.*;
public class FileWriter1 {
public static void main(String args[]) throws IOException
{
	FileWriter fw = new FileWriter("cap.txt");
			fw.write( 97);
	fw.write("sandeep");
	fw.write("\n");
	char[] ch1= {'a','b','c'};
	fw.write( ch1);
	fw.write("\n");
	
	fw.flush();
	fw.close();


}
}
