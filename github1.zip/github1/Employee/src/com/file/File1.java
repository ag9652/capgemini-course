package com.file;
import java.io.*;
class File1 {
public static void main(String args[]) throws IOException {
	File f=new File("capg.txt");
	f.createNewFile();
	System.out.println("file created");
}
}
