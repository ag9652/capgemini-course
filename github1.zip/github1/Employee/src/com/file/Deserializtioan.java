package com.file;
import java.io.*;
public class Deserializtioan {
public static void main(String args[]) throws IOException,ClassNotFoundException
{
	FileInputStream fis = new FileInputStream( "capgemini.txt");
	ObjectInputStream ois = new ObjectInputStream( fis);
	Student st = (Student)ois.readObject();
	System.out.println(st.getSno());
	System.out.println(st.getName());
	System.out.println(st.getAddress());
	ois.close();
}
}
