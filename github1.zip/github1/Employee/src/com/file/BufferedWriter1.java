package com.file;
import java.io.*;

public class BufferedWriter1 {
	public static void main(String args[]) throws IOException
	{
		FileWriter fw = new FileWriter("adb.txt");
		BufferedWriter bw = new BufferedWriter(fw);
				bw.write(101);
				bw.newLine();
		
		//char[] ch1= {'a','b','c'};
		//bw.write( ch1);
		//bw.newLine();
		bw.write("welcome");
		bw.newLine();
		bw.write("gopal");
		bw.flush();
		bw.close();
		fw.close();


	}
}
