package com.file;
import java.io.*;
class Student implements Serializable{
	private int sno;
	private String name;
	private String address;

public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
	public class Sereialization{
public static void main(String args[]) throws IOException{
	Student student=new Student();
	student.setSno(1011);
	student.setName("gopal");
	student.setAddress("Narsapur");
	FileOutputStream fos=new FileOutputStream( "capgemini.txt");
	ObjectOutputStream oos=new ObjectOutputStream(fos);
	oos.writeObject(student);
	System.out.println("success");
}
}