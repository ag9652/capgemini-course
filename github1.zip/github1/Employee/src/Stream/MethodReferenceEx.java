package Stream;

interface A {
	int add(int a, int b);
}

public class MethodReferenceEx {
	public static int sum(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {
		A a1 = (a, b) -> {
			return a + b;
		};
		System.out.println(a1.add(12, 13));
		A a2 = MethodReferenceEx::sum;
		System.out.println(a2.add(123, 22));
	}
}
