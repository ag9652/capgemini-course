package Stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Arraylist1 {
public static void main(String[] args) {

    ArrayList<Integer> al=new ArrayList<Integer>();
    al.add(22);
    al.add(45);
    al.add(12);
    System.out.println(al);
    //Iterator itr = al. iterator();
    //while(itr.hasNext())
    //{
    	//Integer n = (Integer) itr.next();
    	//if(n%2==0)
    	//System.out.println(n);
    	//}
    List<Integer> l1= al.stream().filter(n->n%2==0).collect(Collectors.toList());
    System.out.println(l1);
    List<Integer> l2= al.stream().map(n->n+5).collect(Collectors.toList());
    System.out.println(l2);
    List<Integer> l3= al.stream().filter(n->n>20).collect(Collectors.toList());
    System.out.println(l3);
    long numcount= al.stream().filter(i->i>20).count();
    System.out.println(numcount);
    List<Integer> l4= al.stream().sorted((i1,i2)->(i1<i2)? 1:(i1>i2)? -1 : 0).collect(Collectors.toList());
    System.out.println(l4);
    Integer minVal = al.stream().min((i1,i2) -> -i1.compareTo(i2)).get();
    System.out.println("minimum value is :"+minVal);
    Integer maxVal = al.stream().min((i1,i2) -> -i2.compareTo(i1)).get();
    System.out.println("minimum value is :"+maxVal);
    al.stream().forEach(i->{
    	System.out.println("the elements are :"+i);
    });
}
}
