package Stream;

import java.util.ArrayList;

import org.omg.Messaging.SyncScopeHelper;

public class MethodReferenceEx2 {
public static void main(String[] args) {
ArrayList<Integer> al =new ArrayList<>();
al.add(544);
al.add(15);
System.out.println(al);
al.stream().forEach(System.out::println);
}
}
