package Lambda;

import java.util.ArrayList;
import java.util.function.BiConsumer;

class Employee1{
	String ename;
	double sal;
	public Employee1(String ename, double sal) {
		super();
		this.ename = ename;
		this.sal = sal;
	}
	@Override
	public String toString() {
		return ename+ " "+sal;
	}
}
public class BiConsumerEx {
 public static void main(String[] args) {
	 ArrayList<Employee1> al = new ArrayList<Employee1>();
BiConsumer<Employee1,Double> bic = (emp,sal1)->emp.sal=emp.sal+sal1;

		Employee1 e1 = new Employee1( "gopal", 20000);
		Employee1 e2 = new Employee1("gopal3",2000);
		Employee1 e3 = new Employee1("gopal1",20001);
		Employee1 e4 = new Employee1("gopal2",20004);

		al.add(e1);
		al.add(e2);
		al.add(e3);
		al.add(e4);
		for(Employee1 e : al)
		{
			bic.accept(e,(double) 10000);
			
		}
		System.out.println(al);
}
}
