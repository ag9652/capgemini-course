package Lambda;
interface A1
{
	static void m3() {
	}


	 abstract void m1();
	 default void m2() {
	}
	
}
 class StaticEx implements A1 {
	 public void m2() {
		 System.out.println("gopal");		
		 	}
	@Override
	public void m1() {
System.out.println("hi");		
	}
public static void main(String[] args) {
	StaticEx se= new StaticEx();
	se.m1();
	se.m2();
	se.m3();
}
private void m3() {
	System.out.println("yaa");
}
}
