package Lambda;
interface A
{
	 abstract void m1();
	 default void m2() {
		 System.out.println("hello");
	}
	
}
 class B implements A {
	 public void m2() {
		 System.out.println("gopal");		
		 	}
	@Override
	public void m1() {
System.out.println("hi");		
	}
public static void main(String[] args) {
	B b= new B();
	b.m1();
	b.m2();
}
}
