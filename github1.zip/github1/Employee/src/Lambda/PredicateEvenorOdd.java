package Lambda;

import java.util.function.Predicate;

public class PredicateEvenorOdd {
public static void main(String[] args) {
	int a[] = {1,2,34,14,5,66};
	Predicate<Integer> p = i->i%2==0;
	Predicate<Integer> p1 = i->i>10;
	
	System.out.println("the number greater than 10 and even");
	for(int i1 :a)
	{
		if(p.and(p1).test(i1))
		{
			System.out.println(i1);
		}

		if(p.negate().test(i1))
		{
			System.out.println(i1);
		}
		if(p.or(p1).test(i1))
		{
			System.out.println(i1);
		}
	}
}
}
