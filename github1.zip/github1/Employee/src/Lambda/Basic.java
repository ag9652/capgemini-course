package Lambda;
@FunctionalInterface
interface Favourite
{	

	public int mul(int n);
}
public class Basic {
public static void main(String[] args) {
	Favourite f= (n)->  n*n;
	int n=12;
	System.out.println();;
}
}
