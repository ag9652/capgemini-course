package Lambda;

import java.util.function.Function;

public class FunctionFunctionalInterfaceEx {
public static void main(String[] args) {
	String s="gopal";
	Function<String,String> f = i->i.toUpperCase();
	Function<String,Integer> f1 = i->i.length();
	System.out.println(f.apply(s));

	System.out.println(f1.apply(s));
}
}
