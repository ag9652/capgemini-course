package Lambda;

import java.util.function.Consumer;

public class ConsumerEx {
public static void main(String[] args) {
	Consumer<String> con = i-> System.out.println(i);
	con.accept("welcome gopal");
	con.accept("company");
	
}
}
