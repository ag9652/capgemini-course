package Lambda;

import java.util.function.BiPredicate;

public class BiPredicateEx {
	public static void main(String[] args) {
		BiPredicate<Integer, Integer> p = (a, b) -> (a + b) % 2 == 0;
		System.out.println(p.test(12, 12));
		System.out.println(p.test(12, 11));
	}
}
