package com.cap.dao;
import java.util.HashMap;

import com.cap.RechargeBeans.RechargeBean;
public class RechargeDao {
HashMap<String,RechargeBean> acc =null;
public RechargeDao()
{
	System.out.println("hi");
	RechargeBean s= new RechargeBean("prepaid","gopal","855");
	RechargeBean s1= new RechargeBean("prepaid","siva","522");
	RechargeBean s2= new RechargeBean("prepaid","kamal","800");
	RechargeBean s3= new RechargeBean("prepaid","anil","856");
acc = new HashMap<String,RechargeBean>();
acc.put("9652398317", s);
acc.put("9652398452", s1);
acc.put("9652398314", s2);
acc.put("9652398318", s3);

}
public RechargeBean display(String mobnum)
{
	System.out.println("op");
	RechargeBean rb= acc.get(mobnum);
	return rb;
}
}
