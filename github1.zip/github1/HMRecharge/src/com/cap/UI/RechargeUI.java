package com.cap.UI;
import java.util.Scanner;

import com.cap.RechargeBeans.RechargeBean;
import com.cap.Services.RechargeServices;
public class RechargeUI {
public static void main(String[] args) {
	System.out.println("number");
	Scanner sc= new Scanner(System.in);
	String s1=sc.next();
	RechargeServices b1=new RechargeServices();
	RechargeBean rb2= b1.display(s1);
	System.out.println(rb2);
}
}
