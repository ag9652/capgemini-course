package com.cap.RechargeBeans;
import java.io.Serializable;
public class RechargeBean implements Serializable {
	private String accounttype;
	private String name;
	private String balance;
	public RechargeBean(String accounttype,String name,String balance)
	{
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	
}
