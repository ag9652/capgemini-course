package com.cap.Services;
import java.util.Scanner;
import com.cap.RechargeBeans.RechargeBean;
import com.cap.dao.RechargeDao;
public class RechargeServices 
{
RechargeDao dao=new RechargeDao();
public RechargeBean display(String mobnum)
{
System.out.println("opi");
RechargeBean rb1=dao.display(mobnum);
return rb1;
}
}
