package com.ui;
import java.util.Scanner;
import com.bean.Bean;
import com.service.Service;
import exception.EmpException;
public class Ui 
{
	public static void main(String [] args)
	{
		Scanner scan = new Scanner(System.in);
		Bean b = new Bean();
		Service s = new Service();
		while(true)
		{
			System.out.println("1.add 2.getall 3.get id");
			int choice = scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter the details");
				String empname;
				do {
					System.out.println("Enter name");
					 empname = scan.next();
					
				}while(!s.isValid(empname));
				System.out.println("enter sal");
				float empsalary=scan.nextFloat();
						
				int id = (int) (Math.random()*12345);
				b = new Bean(empname,empsalary,id);
				s.insertEmployee(b);
				System.out.println("Employee added successfully with Id " + id);
				break;
				
			case 2:
				try {
					System.out.println(s.getAllEmployees());
				} catch (EmpException e) {
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Enter id");
				int empid =scan.nextInt();
				try {
					System.out.println(s.getEmployeeById(empid));
				} catch (EmpException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					break;
				}}}}}