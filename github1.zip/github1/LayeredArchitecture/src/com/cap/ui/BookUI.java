package com.cap.ui;

import java.util.Scanner;

import com.cap.services.BookService;

public class BookUI {
public static void main(String[] args) {
	int bookid=0;
	String tittle=" ";
	float price =0;
	Scanner sc= new Scanner(System.in);
	System.out.println("enter book id");
	bookid=sc.nextInt();
	System.out.println("enter book title");
	tittle=sc.next();
	System.out.println("enter book price");
	price=sc.nextFloat();
	BookService bs= new BookService();
	int result = bs.addBook(bookid, tittle, price);
	System.out.println(result+"record inserted");
}
}
