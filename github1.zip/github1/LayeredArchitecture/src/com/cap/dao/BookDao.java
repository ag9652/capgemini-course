package com.cap.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import com.cap.BookBeans.*;
public class BookDao {
public int addbook(BookBean bookBean)
{
	Connection conn=null;
	PreparedStatement pstmt = null;
	try {
		conn = BookDB.getConnection1();
		String ins_str = "insert into book values(?,?,?,?) ";
		pstmt = conn.prepareStatement(ins_str);
		pstmt.setInt(1, bookBean.getBookid());
		pstmt.setString(2, bookBean.getTittle());
		pstmt.setFloat(3, bookBean.getPrice());
		pstmt.setString(4, bookBean.getGrade());
		int updateCount=pstmt.executeUpdate();
		conn.close();
		return updateCount;
		}
	catch(Exception e)
	{
		System.out.println(e.toString());
		return 0;
	}
}
}
