package com.cap.dao;

import com.cap.BookBeans.BookBean;

public interface BookDaoI {
	int addBook(BookBean bookBean);

}
