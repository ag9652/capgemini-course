package com.cap.services;
import com.cap.BookBeans.*;
public interface BookServiceI {
int addBook( int bookid,String tittle,float price);
}
