package com.cap.services;
import com.cap.BookBeans.BookBean;
import com.cap.dao.*;

public class BookService implements BookServiceI {

	@Override
	public int addBook(int bookid, String tittle, float price) {
		String grade="";
		if(price <=300)
		{
			grade="c";
		}
		else if(price<=600)
		{
			grade="b";
		}
		else
		{
			grade="a";
		}
		BookDao bookDAO = new BookDao();
		BookBean bookBean = new BookBean();
		bookBean.setBookid(bookid);
		bookBean.setTittle(tittle);
		bookBean.setPrice(price);
		bookBean.setGrade(grade);
		int updateResult=0;
		try {
			updateResult = bookDAO.addbook(bookBean);
			return updateResult;
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
			return 0;
		}
	}	

}