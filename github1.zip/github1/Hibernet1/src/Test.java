import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;

public class Test {
    public static void main(String args[]) {
    Configuration cfg = new Configuration();
    cfg.configure();

    SessionFactory factory = cfg.buildSessionFactory();

    Session session = factory.openSession();
    Employee emp=(Employee) session.get(Employee.class,new Integer(123));
    System.out.println(emp.getEid());
   
   /* Transaction tran = session.beginTransaction();

 
    Employee emp = new Employee(123, "rithu", 12000);
    session.save(emp);


    tran.commit();*/
   session.close();
    factory.close();
}
}
