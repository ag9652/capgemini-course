package com.cg.service;

import com.cg.bean.Account;

public interface MobileServieI {
	public Account getdetails(String mno);
	public double getrecharge(String mno1, double recharge); 


}
