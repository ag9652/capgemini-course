package com.cg.dao;

import com.cg.bean.Account;

public interface MobileDaoI {
	public Account getdetails(String mno);
	public double getrecharge(String mno1, double recharge);


}
