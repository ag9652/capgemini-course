package Com.capgemini.fms.dao;

public class InvalidSubjectException extends Exception{
		public InvalidSubjectException()
		{
			super("The subject must be either 'math' or 'english'");//This message is passed to user data for entering of invalid subject name
		}
	}


