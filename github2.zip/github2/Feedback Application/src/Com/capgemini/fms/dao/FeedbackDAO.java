package Com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class FeedbackDAO implements IFeedbackDAO {
	Map<String, Integer> MathFeedbackMap=new HashMap<String, Integer>();//HashMap to store the math subject values.
	Map<String, Integer> EnglishFeedbackMap=new HashMap<String, Integer>();//HashMap to store the English subject values.
	Map<String, Integer> newFeedbackMap=new HashMap<String, Integer>();
	
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject)				
	{
		newFeedbackMap.clear();
		 if(subject.equalsIgnoreCase("English"))
			{
				EnglishFeedbackMap.put(name, rating);
				newFeedbackMap.putAll(EnglishFeedbackMap);//storing the details in MathFeedback hash map.
			}
		 else if(subject.equalsIgnoreCase("Math"))
		{
			MathFeedbackMap.put(name, rating);
			newFeedbackMap.putAll(MathFeedbackMap);;
		}
		return newFeedbackMap;											//fetching of feedback details.
	}
	
	@Override
	public Map<String, Integer> getFeedbackReport() {				
		Set engset=EnglishFeedbackMap.entrySet();
		Iterator i=engset.iterator();
		String string;
		newFeedbackMap.putAll(MathFeedbackMap);
		while(i.hasNext())
		{
			Map.Entry<String, Integer> map=(Map.Entry<String, Integer>)i.next();
			string=map.getKey();
			if(newFeedbackMap.containsKey(string))
			{
				int a1=newFeedbackMap.get(string);
				if(a1<map.getValue())
				{
					newFeedbackMap.remove(string);
					newFeedbackMap.put(string, map.getValue());			//storing the details in EnglishFeedback hash map.
				}
			}
			else
			{
				newFeedbackMap.put(string, map.getValue());
			}
		}
		return newFeedbackMap;         									//fetching of feedback details.
	}
}
