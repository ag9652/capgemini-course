package Com.capgemini.fms.dao;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Test;

public class FeedbackJUNITTest {
	FeedbackDAO dao=new FeedbackDAO();
	String name="Geetanjali";
	int rating=5;
	String subject="math";
	@Test
	public void test() {
		Map a=dao.addFeedbackDetails( name,  rating,  subject);
		System.out.println(a);
		assertEquals(5, a.get(name));
		
	}

}
