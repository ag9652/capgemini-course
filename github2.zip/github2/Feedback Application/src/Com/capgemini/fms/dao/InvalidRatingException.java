package Com.capgemini.fms.dao;

public class InvalidRatingException extends Exception {
		public InvalidRatingException()
		{
			super("The rating must be between 1 and 5");	////This message is passed to user data for entering of invalid rating.	
			}
	}

