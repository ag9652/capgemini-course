package Com.capgemini.fms.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


import Com.capgemini.fms.bean.Feedback;
import Com.capgemini.fms.service.FeedbackService;

public class Client {

			FeedbackService service=new FeedbackService();											//Service object Creation.
			Scanner scan=new Scanner(System.in);													//Scanner creation.
			Map<String, Integer> map=new HashMap<String, Integer>();
			Map<String, Integer> newmap=new HashMap<String, Integer>();
			void choice()
			{
			while(true)																				//When it is true it enter into main menu
			{
				System.out.println("****************FEEDBACK APPLICATION******************\n1) Add Feedback\n2) Print Feedback Report\n3) Exit");
				String ch = scan.next();			
				switch(ch)																			//Creating of switch case.
				{
				case "1":
					try
					{
						Feedback feedback=new Feedback();													//Feedback object creation.
						System.out.println("Enter Teacher Name:\n");										//dynamically given inputs.
						feedback.setTeacherName(scan.next());												//Teacher name stores in HashMap.											
						System.out.println("Enter Rating:");												//dynamically given inputs.
						feedback.setRating(scan.nextInt());													//Rating stores in HashMap
						
						System.out.println("Enter Subject Name:");											//dynamically given inputs.
						feedback.setTopic(scan.next());														//Subject name stores in HashMap.
						map=service.addFeedbackDetails(feedback.getTeacherName(), feedback.getRating(), feedback.getTopic());//calling method in service by using service object.
						System.out.println("Successfully added to "+feedback.getTopic()+" map");
						showMap(map);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
					break;
				case "2":
					System.out.println("Feedback Report:");
					newmap=service.getFeedbackReport();														
					showMap(map);																			////Feedback Report has to be displayed here.
					break;
				case "3":
					scan.close();
					System.out.println("Thank you");
					System.exit(0);																			//Exit from service.
				default:
					System.out.println("Enter valid Choice");
					break;
				}
			}
			}
		
		public static void showMap(Map<String, Integer> map) {											//Hashmap used to store the values above. 
	
			System.out.println("Map details:");
			System.out.println("Teacher Name  Feedback Rating");
			if(map.isEmpty())
			{
				System.out.println("The map is Empty");
			}
			Set entryset=map.entrySet();
			Iterator i=entryset.iterator();
			while(i.hasNext())
			{
				Map.Entry<String, Integer> me=(Map.Entry<String, Integer>)i.next();
				System.out.println(me.getKey()+"		"+me.getValue());
			}
		}
		public static void main(String[] args) 											//main method which is used to execute.
		{
			Client ui = new Client();													//Client object Creation.
			ui.choice();

		}
}
