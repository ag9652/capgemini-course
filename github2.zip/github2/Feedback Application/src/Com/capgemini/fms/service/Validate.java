package Com.capgemini.fms.service;

import Com.capgemini.fms.dao.InvalidRatingException;
import Com.capgemini.fms.dao.InvalidSubjectException;

public class Validate {
	public void ValidationofInput(String name, int rating, String subject) throws Exception{
		try
		{
			validateRating(rating);
			validateSubject(subject);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	private void validateSubject(String subject) throws InvalidSubjectException {
		if(subject.equalsIgnoreCase("Math") || subject.equalsIgnoreCase("English")) {
			
		}
		else
		{
			throw new InvalidSubjectException();
		}
	}

	private void validateRating(int rating) throws InvalidRatingException {
		if(rating<=0 || rating>5)
		{
			throw new InvalidRatingException();
		}
	}

}