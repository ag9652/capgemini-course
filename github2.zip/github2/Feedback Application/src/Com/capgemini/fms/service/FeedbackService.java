package Com.capgemini.fms.service;

import java.util.Map;

import Com.capgemini.fms.dao.FeedbackDAO;

public class FeedbackService {
	FeedbackDAO dao=new FeedbackDAO();
	Validate val=new Validate();
	public Map<String, Integer> getFeedbackReport() {			/////get all details that has to be entered from the user.
		return dao.getFeedbackReport();
	}
	
	
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) throws Exception {
		try
		{
			val.ValidationofInput(name, rating, subject);//validation has to be done for  the given data.
			
			return dao.addFeedbackDetails(name, rating, subject);
		}
		catch(Exception e)
		{
			throw e;												//Throws exception for input entries.
		}
	}

	
}
