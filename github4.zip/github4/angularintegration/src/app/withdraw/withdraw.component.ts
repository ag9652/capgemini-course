import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  bankService: BankService;
  transaction: Transaction;

  constructor(bankService: BankService) { 
    this.bankService = bankService;
  }

  withdrawBalance(data: any){
    let transId = Math.floor(Math.random()*100) + 10;
    this.transaction = new Transaction(transId,"Withdraw",data.withdrawbalance, data.withdrawaccountno);  
    this.bankService.withdrawBalance(data, this.transaction);
  }
  
  ngOnInit() {
  }

}
