package com.cap.parallelservices;

import java.util.List;

import com.cap.parallelBean.BankBean;
import com.cap.parallelBean.TransBean;
import com.cap.parallelDAO.BankDAO;

public class BankService implements BankServiceI
{
    BankDAO d =new BankDAO();
	public boolean createAccount(BankBean bean)
	{
		
		d.createAccount(bean);
		if(d.createAccount(bean))
		{
					return true;
		}
		return false;
	}
	public  int showbalance(long accountno1,String password1)
	{
		int balance =(int)d.showbalance(accountno1, password1);
		return balance;
	}
	public int deposit(long accountno2,String password2,int dep1)
	{
		int d1=(int) d.deposit1( accountno2,password2,dep1);
		return d1;
	}
	public int withdraw(long accountno21, String password21, int witdr)
	{
		
		int d1=(int) d.withdraw( accountno21,password21,witdr);
		return d1;
	}
	public int fund(long accountno31,long accountno32,String password31,int k1)
	{
		int d11=d.fund1( accountno31, accountno32, password31, k1);
		return d11;
	}
	
	public boolean validation(long accountno1, String password1) {
		
		
		boolean d11=d.validation(accountno1, password1);
		return d11;
	}
	public boolean validation1(long accountno31, long accountno32, String password31) {
		
		boolean d11=d.validation1(accountno31, accountno32, password31);
		return d11;
	}
	public List<TransBean> trans() {
		List<TransBean> q12=d.transa();
		
		
		return q12;
	}
	@Override
	public long deposit1(long accountno2, String password2, int dep1) {
		
		return 0;
	}
	@Override
	public int fund1(long accountno31, long accountno32, String password31, int k1) {
		
		return 0;
	}
	
	
}

