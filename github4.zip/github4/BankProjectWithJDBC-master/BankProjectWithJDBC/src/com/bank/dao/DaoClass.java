package com.bank.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.*;

import com.bank.user.bean.UserBean;


public class DaoClass implements DaoInterface {
	PreparedStatement ps = null;
	Connection conn = null;
	
	 HashMap<String, UserBean> UserAccountData;
	 public DaoClass() {
		 UserAccountData = new HashMap<String, UserBean>();
		}
	
	UserBean a1; 
	SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat sd1 = new SimpleDateFormat("HH:mm:ss");

	
	public int userAccountCreate(String accountId, UserBean userbean) {
		
		String accountId1 = userbean.getAccountId();
		String userName = userbean.getName();
		String userPassword = userbean.getAccountPassword();
		long mobileNumber = userbean.getMobileNumber();
		int balance = userbean.getBalance();
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gopal","gopal123");
		
			ps = conn.prepareStatement("insert into bankdetails values(?,?,?,?,?)");
			
			ps.setString(1, accountId1);
			ps.setString(2,userName);
			ps.setString(3, userPassword);
			ps.setLong(4,mobileNumber);
			ps.setInt(5,balance);
			
			int updateCount = ps.executeUpdate();
			
			conn.close();
			return updateCount;
		}
		catch(Exception ex) {
			System.out.println(ex.getStackTrace());
			return 0;
		}
	
	}
	
	
	public String showBalance(String accountId) {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = 
					DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gopal","gopal123");
			String show_str = "select balance from bankdetails where accountid = ?";
			
			ps = conn.prepareStatement(show_str);
			
			ps.setString(1, accountId);
			
			ResultSet resultSet = ps.executeQuery();

			resultSet.next();
			int balance = resultSet.getInt("balance");
			return "balance is "+balance;

		}
		catch(Exception e) {
			System.out.println(e.getStackTrace());
			return "error";
		}
	

	}
	
	
	@Override
	public int SignIn(String accountId, String accountPassword) {
		int flag = 0;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = 
					DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gopal","gopal123");
			String show_str = "select * from bankdetails where accountid = ? and userpassword = ?";
			
			ps = conn.prepareStatement(show_str);
			
			ps.setString(1, accountId);
			ps.setString(2, accountPassword);
			ResultSet resultSet = ps.executeQuery();
			
			if(resultSet.next()) {
				flag = 1;
			}
	
			return flag;
		}
		catch(Exception e) {
			System.out.println("error");
			System.out.println(e.getStackTrace());
			return 0;
		}
		
	}
	
	//this method use for deposit amount. 
	@Override
	public String Deposit(String accountId, int amount) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = 
					DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gopal","gopal123");
			String dep_str = "update bankdetails set balance = balance + ? where accountid = ?";
			
			ps = conn.prepareStatement(dep_str);
			
			ps.setInt(1, amount);
			ps.setString(2, accountId);
			
			int i = ps.executeUpdate();
			
			conn.close();
			return "Deposit successfull";
		}
		catch(Exception e){
			System.out.println("error");
			System.out.println(e.getStackTrace());
			return "error";
		}
	}
	
	//this method use for withdraw amount.
	@Override
	public String withDraw(String accountId, int amount) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = 
					DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gopal","gopal123");
			String dep_str = "update bankdetails set balance = balance - ? where accountid = ?";
			
			ps = conn.prepareStatement(dep_str);
			
			ps.setInt(1, amount);
			ps.setString(2, accountId);
			
			int i = ps.executeUpdate();
			
			conn.close();
			return "Withdraw successfull";
		}
		catch(Exception e){
			System.out.println("error");
			System.out.println(e.getStackTrace());
			return "error";
		}
	}
	
	
	public String fundTransfer(String sourceAccountId, String destinationAccountId, int amount) {
			a1 = (UserBean) UserAccountData.get(sourceAccountId);
			if (a1.getBalance() >= amount) {
				String date = sd.format(new Date());
				String time = sd1.format(new Date().getTime());
				UserBean a2;
				a2 = UserAccountData.get(destinationAccountId);
				a1.setBalance(a1.getBalance() - amount);
				a2.setBalance(a2.getBalance() + amount);
				a1.setTransaction("Transaction type = Fund Transfer || fromAccount = "+sourceAccountId
						+" || toAccount ="+destinationAccountId+" || Amount = "+amount+"|| Date ="+date+"|| Time = "+time );
				a2.setTransaction("Transaction type = Fund Transfer || fromAccount = "+sourceAccountId
						+" || toAccount ="+destinationAccountId+" || Amount = "+amount+"|| Date ="+date+"|| Time = "+time );
				return "After transfer fund your balance is " + a1.getBalance();
			} else {
				return "You have insufficient amount to transfer";
			}
		
	}
	
	
	@Override
	public String printTransactions(String accountId) {
		a1 = UserAccountData.get(accountId);
		
		
		String s = "";
		Iterator<String> i = a1.getTransaction().iterator();
		while(i.hasNext()) {
			s = s+ "\n"+ (String) i.next();
		}
		return s;
	}

	
	
	public boolean validAccountId(String accountId) {
		if (UserAccountData.containsKey(accountId)) {
			return true;
		} else {
			return false;
		}
	}
	

	public boolean checkBalance(String accountId, int amount) {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = 
					DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","gopal","gopal123");
			
			String chk_str = "select balance from  bankdetails where accountid = ? and balance >= ?";
			
			ps = conn.prepareStatement(chk_str);
			
			ps.setString(1, accountId);
			ps.setInt(2, amount);
			
			ResultSet resultSet = ps.executeQuery();
			if(resultSet.next()) {
				return true;
			}
			
			conn.close();
			return false;
		}
		catch(Exception e){
			System.out.println(e);
			System.out.println(e.getMessage());
			return false;
		}
	}


}
