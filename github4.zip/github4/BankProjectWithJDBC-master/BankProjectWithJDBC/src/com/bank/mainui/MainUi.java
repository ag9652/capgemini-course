package com.bank.mainui;

import java.util.Scanner;

import com.bank.exception.AccountNotFoundException;
import com.bank.exception.InsufficientFundException;
import com.bank.service.BankServiceClass;
import com.bank.service.BankServiceInterface;



public class MainUi {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String userName;
		String accountPassword;
		String mobileNumber;
		String amount;
		
		BankServiceInterface serviceObject = new BankServiceClass();//created object of service class.
		
		
		
		boolean exitFromApp = false;
		
		while(!exitFromApp) {
			
			System.out.println("*************Welcome to dashboard*************");
			System.out.println("Enter 1 for Sign Up\nEnter 2 for Sign In\nEnter 3 for Exit");
			
			String dashboardUserInput = sc.nextLine();
			
			
			switch(dashboardUserInput) {
			
			 	case "1":
			 		
			 		 System.out.println("Enter Your name");
			 		 userName = sc.nextLine();
			 		 String updateName = serviceObject.nameCheck(userName);  
			 		 if(updateName.equals("exit")) {   						
			 			 break;
			 		 }
			 		 
			 		 System.out.println("Enter account password");
			 		 accountPassword = sc.nextLine();
				 	 String updatePassword = serviceObject.passwordCheck(accountPassword);
				 	 if(updatePassword.equals("exit")) { 	
			 			 break;
			 		 }
				 	 
				 	 System.out.println("Enter mobile number");
				 	 mobileNumber = sc.nextLine();
				 	 String updateMobileNumber = serviceObject.mobileNumberCheck(mobileNumber);	 	
				 	 if(updateMobileNumber.equals("exit")) { 
			 			 System.out.println("this");
				 		 break;
			 		 }
				 	 
				 	
				 	 System.out.println(serviceObject.userAccountCreate(updatePassword,updateName,Long.parseLong(updateMobileNumber)));
				 	 break;
				 	 

			 	 case "2":
			 		 
			 		 
			 		 System.out.println("Enter account ID");
			 		 String loggedInAccountId = sc.nextLine();
			 		 
			 		 System.out.println("Enter account password");
			 		 String loggedInAccountPassword = sc.nextLine();
			 		 
			 		 
			 		 int i = serviceObject.SignIn(loggedInAccountId, loggedInAccountPassword);
			 		 boolean returnToDashboard = false; 
			 		 
			 		 if(i == 1) {
			 			System.out.println("Sign in successfull");
			 			while(!returnToDashboard) {
			 				
			 				System.out.println("*************Welcome*************");
			 				System.out.println("Enter 1 for Show Balance\nEnter 2 for Deposit");
			 				System.out.println("Enter 3 for withdraw\nEnter 4 for fund transfer\nEnter 5 for print Transaction");
			 				System.out.println("Enter 6 for exit");
			 				
			 				String signInInput = sc.nextLine();
			 				
			 				
			 				switch(signInInput) {
			 				
			 				 	 case "1":
			 				 		 
			 				 		 System.out.println(serviceObject.showBalance(loggedInAccountId));
			 				 		 break;
			 				 		 
			 				 	 case "2":
			 				 		 
			 				 		 System.out.println("Enter amount you want to deposit");
			 				 		
			 				 		 amount = serviceObject.amountLimitCheck(sc.nextLine());
			 				 		 if(amount.equals("exit")) {
			 				 			 break;
			 				 		 }
			 				 		 
			 				 		
			 				 		 System.out.println(serviceObject.deposit(loggedInAccountId, Integer.parseInt(amount)));
			 				 		 break;
			 				 		 
			 				 	 case "3":
			 				 		 
			 				 		 System.out.println("Enter amount you want to withdraw");
			 				 		 amount = sc.nextLine();
			 				 		 while(true) {
			 				 			 try {
			 				 				amount = serviceObject.checkBalance(loggedInAccountId,amount);
			 				 				break;
			 				 			 }
			 				 			 catch(InsufficientFundException e) {
			 				 				System.out.println(e);
			 				 				System.out.println("Enter again:[Enter exit for dashboard]");
			 				 				amount = sc.nextLine();
			 								if(amount.equals("exit")) {
			 									amount = "exit";
			 									break;
			 								}
			 				 			 } 
			 				 		 }
			 				 		 if(amount.equals("exit")) {
			 				 			 break;
			 				 		 }
			 				 		 System.out.println(serviceObject.withDraw(loggedInAccountId, Integer.parseInt(amount)));
			 				 		 break;
			 				 		 
			 				 	 case "4":
			 				 		
			 				 		 System.out.println("Enter amount you want to Transfer");
			 				 		 amount = sc.nextLine();
			 				 		
			 				 		 while(true) {
			 				 			 try {
			 				 				amount = serviceObject.checkBalance(loggedInAccountId,amount);
			 				 				break;
			 				 			 }
			 				 			 catch(InsufficientFundException e) {
			 				 				System.out.println(e);
			 				 				System.out.println("Enter again:[Enter exit for dashboard]");
			 				 				amount = sc.nextLine();
			 								if(amount.equals("exit")) {
			 									amount = "exit";
			 									break;
			 								}
			 				 			 }		 
			 				 		 }
			 				 		 if(amount.equals("exit")) {
			 				 			 break;
			 				 		 }
			 				 		 
			 				 		 System.out.println("Enter account ID user that you want to transfer amount");
			 				 		 String accountId2 = sc.nextLine() ;
			 				 		 
			 				 		 while(true) { 
			 				 			 try {
			 				 				 accountId2 = serviceObject.validAccountId(accountId2);
			 				 				 break;
			 				 			 }
			 				 			 catch(AccountNotFoundException e) {
			 					 				System.out.println(e);
			 					 				System.out.println("Enter again:[Enter exit for dashboard]");
			 					 				accountId2 = sc.nextLine();
			 									if(accountId2.equals("exit")) {
			 										accountId2 = "exit";
			 										break;
			 									}
			 					 		 	}
			 				 		 	}
				 				 	 if(accountId2.equals("exit")) {
				 				 			 break;	 
			 				 		 }
			 				 		
			 				 		 System.out.println(serviceObject.fundTransfer(loggedInAccountId, accountId2,Integer.parseInt(amount)));
			 				 		 break;
			 				 		 
			 				 	 case "5":
			 				 		
			 				 		 System.out.println(serviceObject.printTransactions(loggedInAccountId));
			 				 		 break;
			 				 		 
			 				 	 case "6":
			 				 		  
			 				 		 returnToDashboard = true ;
			 				 		 break;
			 				 	 default:
			 				 		System.out.println("enter valid input");
			 				}
			 			}
			 		 }
			 		 else {
			 			 System.out.println("Wrong Credentials");
			 		 }
			 		 break;
			 	 case "3":
			 		 exitFromApp = true;
			 		 break;
			 	default:
			 		System.out.println("enter valid input");
			}
		}
		sc.close();
		System.out.println("Thank You for using application");
		System.exit(1);

	}

}
