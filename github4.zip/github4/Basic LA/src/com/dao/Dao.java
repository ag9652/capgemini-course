package com.dao;
import java.util.HashMap;
import com.bean.Bean;
import exception.EmpException;
public class Dao 
{
	Bean b= new Bean();
	
		private static HashMap<Integer,Bean> map=new HashMap<Integer,Bean>();
	    public static void setMap(HashMap<Integer,Bean> map)
	    {
			Dao.map=map;
	    }  
	    public static HashMap<Integer,Bean> getMap()
	    {
			return map;
	    }
	public void insertEmployee(Bean b) 
	{
		map.put(b.getId(), b);
	}
	
	public HashMap<Integer, Bean> getAllEmployees() throws EmpException 
	{
		return map;
	}
	public Bean getEmployeeById(int id) throws EmpException
	{
		if(map.containsKey(id))
		{
			b =map.get(id);
		}
		else
		{
			throw new EmpException("NO record found");
		}
		return b;		
	}  
}