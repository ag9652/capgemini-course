package com.service;
import java.util.HashMap;
import java.util.regex.Pattern;
import com.bean.Bean;
import com.dao.Dao;
import exception.EmpException;
public class Service 
{
	Dao d;
	public Service()
	{
		d = new Dao();
	}
	public void insertEmployee(Bean b) 
	{
		d.insertEmployee(b);	
	}
	public HashMap<Integer, Bean> getAllEmployees() throws EmpException 
	{
		return d.getAllEmployees();	
	}
	public Bean getEmployeeById(int id) throws EmpException 
	{
		return d.getEmployeeById(id);
	}
	public boolean isValid(String empname) 
	{
		boolean b =false;
		 if(Pattern.matches("([A-Z])*([a-z])*", empname)&&empname.length()>=3 && Character.isUpperCase(empname.charAt(0)) )
			 b =true;
		return b;
	}
	
	
	}