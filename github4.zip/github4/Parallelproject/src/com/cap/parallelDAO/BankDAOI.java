package com.cap.parallelDAO;

import com.cap.parallelBean.BankBean;

public interface BankDAOI 
{
public long createAccount(BankBean bean);
public int showbalance(long accountno1,String password1);
public long deposit1(long accountno2,String password2,int dep1);
public int withdraw(long accountno21, String password21, int witdr);
public int fund1(long accountno31, long accountno32, String password31, int k1);
public boolean validation(long accountno1,String password1);
public boolean validation1(long accountno31,long accountno32,String password31);


}
