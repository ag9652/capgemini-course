package com.cap.parallelUI;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import com.cap.parallelBean.BankBean;
import com.cap.parallelBean.TransBean;
import com.cap.parallelDAO.AccountNotFoundException;
import com.cap.parallelservices.BankService;

public class BankUI {
	
	BankService b = new BankService();
   static Scanner sc = new Scanner(System.in);

void stmt()
{
	System.out.println("************YOUR BANK**************");
	System.out.println("1.creation of Account");
	System.out.println("2.show Balance");
	System.out.println("3.Deposit Money");
	System.out.println("4.withdraw Money");
	System.out.println("5.Transfer Money");
	System.out.println("6.Print Transactions");
	System.out.println("7.Exit");
}
  void choose()
  {
	  while(1!=0)
	  {
		  stmt();
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			int n=sc.nextInt();
	
	
	switch(n)
	{
	case 1:  
			System.out.println("enter name");
			String name = nameCheck(sc.next());
			System.out.println("enter DOB");
			String dOB = dateCheck(sc.next());
			System.out.println("enter password");
			String password = sc.next();
			System.out.println("enter Phoneno");
			long phoneno = numbercheck(sc.nextLong());
			System.out.println("minimum balance is : 10 ");
			int balance=1000;
			long accountno=phoneno+1000;
			
			BankBean bean =new BankBean(accountno,name,dOB,password, balance,phoneno);
			b.createAccount(bean);
//			if(b.createAccount(bean))
//			{
//				System.out.println("account is created");
//				System.out.println(bean);
//				
//			}
//			break;
//			
	case 2:
		System.out.println("enter your account number");
		long accountno1=sc.nextLong();
		System.out.println("enter password");
		String password1=sc.next();
	//	boolean val1=b.validation(accountno1, password1);
		try {
			
		
			//System.out.println("account is valid and password is correct");
			int a1=b.showbalance(accountno1, password1);
			System.out.println("Available balance :"+a1);
		}
		catch(AccountNotFoundException a)
		{
			System.out.println(a.getMessage());
		}
		
		break;

	case 3:
		System.out.println("enter account number");
		long accountno2=sc.nextLong();
		System.out.println("enter password");
		String password2=sc.next();
		boolean val2=b.validation(accountno2, password2);
		if(val2)
		{
			System.out.println("account is valid and password is correct");
			System.out.println("enter deposit amount");
			int dep1=sc.nextInt();
			int al1=b.deposit(accountno2,password2,dep1);
			System.out.println("balance after deposit");
			System.out.println(al1);
		}
		else
		{
			System.out.println("enter valid accountno and password");
		}
		break;
	
	  case 4:																													//withdraw amount
			System.out.println("enter account number");
			long accountno21=sc.nextLong();
			System.out.println("enter password");
			String password21=sc.next();
			boolean val3=b.validation(accountno21, password21);
			if(val3)
			{
				System.out.println("account is valid and password is correct");
				System.out.println("enter withdraw amount");
				int witdr=sc.nextInt();
				int al11=b.withdraw(accountno21,password21,witdr);
				System.out.println("balance after withdraw");
				System.out.println(al11);
			}
			else
			{
				System.out.println("enter valid accountno and password");
			}
			break;
			
	  case 5:																												//transfer amount from one account to another
		  System.out.println("enter account 1 to send funds");
		  long accountno31=sc.nextLong();
		  System.out.println("enter account 2 to recieve funds");
		  long accountno32=sc.nextLong();
		  System.out.println("enter password of account 1");
		  String password31=sc.next();
		  boolean val4=b.validation1(accountno31,accountno32,password31);
		  if(val4)
		  {
			  System.out.println("account is valid and password is correct");
			  System.out.println("enter fund amount");
			  int k1=sc.nextInt();
			  int balance2=b.fund(accountno31,accountno32,password31,k1);
			  System.out.println("account 1 balance is:");
			  System.out.println(balance2);
		  }
		  else
		  {
			  System.out.println("enter valid accountno and password");
		  }
		  break;
	  case 6:																														//transaction details
		  System.out.println("enter account number");
	         // long =sc.nextLong();
	          List<TransBean> aq1=b.trans();
	          System.out.println(aq1);
	          break;
	  case 7:
	      System.out.println("**********THANK YOU***********");
	       break;
	  
		}
	  }
	  
	  }
	 

	public static long numbercheck(long phoneno)
	 {
		 while(true)
		 {
		 if(String.valueOf(phoneno).length()==10)
		 {
			// System.out.println("your number is correct");
			 return phoneno;
		}
		 else
		 {
			 System.out.println("enter valid mobile number");
			 
			 phoneno=sc.nextLong();
		 }
		 }
		
	 }
	public static  String nameCheck(String name)
	 {
		 while(true)
		 {
		 if(Pattern.matches("([A-Z][a-zA-Z]*?)",name))
		{
			 return name;
	    }
		 else
		 {
			 System.out.println("please enter the valid name");
			 System.out.println("please enter name again ");
			 name = sc.next();
		 }
		 }
		 
	}
	public static String dateCheck(String dOB)
	{
		while(true)
		{
		if(Pattern.matches("[0-9]{8}", dOB))
		{
			return dOB;
		}
		else
		{
			System.out.println("please enter valid date of birth");
			System.out.println("please enter the date of birth again");
			dOB=sc.next();
		}
		}
		
	}
	public static String passwordCheck(String password)
	{
		while(true)
		{
			if(Pattern.matches("[A-Z][A-Za-z]", password))
			{
				return password;
			}
		else
		{
			System.out.println("please enter valid password with starting capital");
			password=sc.next();
		}
		}	
		
	}
  public static void main(String[] args) {
	System.out.println("************YOUR BANK**************");
	BankUI a1= new BankUI();
	a1.choose();
}
}
