package com.Parallelproject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
 class employee
{
	private String ename;
	private int a;
	

public employee(int a, String ename)
{
	this.ename=ename;
	this.a=a;
}


@Override
public String toString() {
	return " " + ename + " " + a + "";
}
}
public class Mapconv {
public static void main(String[] args) {
	employee e =new employee(22000,"gopal");
	employee e1 =new employee(22000,"gopae");
	employee e2 =new employee(22000,"gopalle");
	employee e3 =new employee(22000,"gopaejh");
	

	HashMap< Integer,employee> hm=new HashMap< Integer,employee>();
	hm.put(121, e);
	hm.put(122, e1);
	hm.put(123, e2);
	hm.put(124, e3);
	
	hm.keySet();
	Set<?> s=hm.entrySet();
	Iterator<?> itr= s.iterator();
	while(itr.hasNext())
	{
		Entry<?, ?> es=(Entry<?, ?>) itr.next();
		System.out.println(es.getKey()+" "+es.getValue());
	}
}
}
