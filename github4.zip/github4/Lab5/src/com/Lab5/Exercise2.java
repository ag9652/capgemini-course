package com.Lab5;
import java.util.*;
public class Exercise2 {
public static void main(String[] args) {
	int a=0,b=1,sum=0,n;
	Scanner sc  = new Scanner(System.in);
	n=sc.nextInt();
	for(int i=1;i<n;i++)
	{
		sum=a+b;
		a=b;
		b=sum;
	}
	System.out.println(sum);
	int pr=printFibonacci(n);
	System.out.println("\n"+pr);
}
static int printFibonacci(int n)
{
	if(n==0)
	{
		return 0;
	}
	else if(n==1)
	{
		return 1;
	}
	else
	{
		return printFibonacci(n-1)+printFibonacci(n-2);
	}
}
}
