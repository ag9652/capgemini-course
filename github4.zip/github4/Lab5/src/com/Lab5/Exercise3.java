package com.Lab5;
import java.util.*;
public class Exercise3 {
static  void m1(int n)
{
	int l,i;
	for(i=0;i<=n;i++)
	{
		l=0;
		for(int j=1;j<=n;j++)
		{
			if(i%j==0)
				l++;
		}
		if(l==2)
		{
			System.out.println(i);
		}
	}
}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the num");
	int n=sc.nextInt();
	Exercise3.m1(n);
	sc.close();
}
}
