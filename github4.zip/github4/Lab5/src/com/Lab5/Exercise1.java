package com.Lab5;
import java.util.*;
public class Exercise1 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	String s=sc.nextLine();
	System.out.println("1:RED");
	System.out.println("2:YELLOW");
	System.out.println("3:GREEN");
	int n=sc.nextInt();
	switch(n)
	{
	case 1:
	{
		System.out.println("Stop");
		break;
	}
	case 2:
	{
		System.out.println("Ready");
		break;
	}
	case 3:
	{
		System.out.println("Go");
		break;
	}
	default:
	{
		break;
	}
	}
	sc.close();
}
}
