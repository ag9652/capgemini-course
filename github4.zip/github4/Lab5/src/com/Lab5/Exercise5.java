package com.Lab5;
import java.util.Scanner;
class Myex extends Exception
{
	int b;
	Myex(int a)
	{
		b=a;
	}
	public String toString()
	{
		return "invalid"+b;
	}
}
public class Exercise5 {
void m1(int a)throws Myex
{
	if(a>15)
	{
		System.out.println("valid");
	}
	else
	{
		throw new Myex(a);
	}
}
public static void main(String[] args) throws Myex
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the age");
	int a=sc.nextInt();
	Exercise5 s= new Exercise5();
	s.m1(a);
	sc.close();
}
}
