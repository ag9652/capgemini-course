package com.cg.eis.exception;
import java.util.*;

public class Exercise6 {
static void m6(int a) throws EmployeeException
{
	if(a>=3000)
	{
		System.out.println("fair salary");
	}
	else
	{
		throw new EmployeeException();
	}
	
}
public static void main(String[] args) throws  EmployeeException
 {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the salary");
	int a=sc.nextInt();
	Exercise6.m6(a);
	sc.close();
}
}
