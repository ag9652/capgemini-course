package com.Lab3;
import java.util.Scanner;
public class Exercise1 {
public static void main(String args[])
{
	int n;
	Scanner sc=new Scanner(System.in);
	n=sc.nextInt();
	int[] a=new int[n];
	for(int i=0;i<n;i++)
	{
		a[i]=sc.nextInt();
	}
	int t=getsecondsmallest(a,n);
	System.out.println(t+"is the secondsmallest number");
}

public static int getsecondsmallest(int[] a, int n) {
	int i,j,temp;
	for(i=0;i<=n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	i=0;
	return a[i+1];
}
}
