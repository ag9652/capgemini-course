package Lab4;
import java.util.Scanner;
public class Exercise {

public static int m1(int n)
{
	int s=0;
	while(n>0)
	{
		int t=n%10;
		s+=t*t*t;
		n/=10;
	
	}
	return s;

}
public static void main(String args[])
{
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the num ");
	int n=sc.nextInt();
	int s=m1(n);
	System.out.println("sum of the cubes is"+s);
}
}