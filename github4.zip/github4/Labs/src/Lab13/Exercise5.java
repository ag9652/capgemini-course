package Lab13;

import java.util.Scanner;

interface factorialI{
	int factI(int n);
	default int n2(int n) {
		return n *n;
	}
}


class FactClass{
	public int fact(int n) {
		if(n == 0) {
			return 1;
		}
		else if(n == 0) {
			return 1;
		}
		else {
			return n * fact(n - 1);
		}
	}
}

public class Exercise5 {
	static factorialI f ;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter integer");
		int num = sc.nextInt();
		sc.nextLine();
		
		FactClass fc = new FactClass();
		factorialI f = fc::fact;
		
		System.out.println("using method reference "+f.factI(num));
		f = (n) -> {
			if(n == 0) {
				return 1;
			}
			if(n == 1) {
				return 1;
			}
			else {
			return n * fc.fact(n-1);
			}
		};
		
		System.out.println("using lambda expression "+fc.fact(num));
		sc.close();
	
}
}