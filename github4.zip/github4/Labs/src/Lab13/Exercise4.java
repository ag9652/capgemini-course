package Lab13;


interface AnyClassI {
	void setname(String name);

}

class AnyClass{
	private String name;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
public class Exercise4{
	
	public static void main(String[] args) {
		AnyClass ac = new AnyClass();
		AnyClassI a2 = ac::setName;
		a2.setname("gopal");
		System.out.println(ac.getName());
		
	}
	
	
}
