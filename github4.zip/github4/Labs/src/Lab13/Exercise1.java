package Lab13;

import java.util.Scanner;

@FunctionalInterface
interface powI{
	public double powerFind(double x,double y);
}

public class Exercise1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first number");
		double a = sc.nextDouble();
		sc.nextLine();
		System.out.println("Enter second number");
		double b = sc.nextDouble();
		
		powI lm = (double x,double y) -> {return Math.pow(a, b);};
		System.out.println(lm.powerFind(a, b));
	}
}