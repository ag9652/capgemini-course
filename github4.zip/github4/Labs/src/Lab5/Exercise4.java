package Lab5;
import java.util.*;
class Excp extends Exception {
public Excp()
{
	
}
public String toString() {
	return "invalid";
}
}
public class Exercise4
{
	void m1(String a,String b) throws Excp
	{
		if(a.equals("")||b.equals(""))
		{
			throw new Excp();
		}
		else
		{
			System.out.println("valid");
		}
	}
	public static void main(String[] args) throws Excp {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter first name");
		String a= sc.nextLine();
		System.out.println("enter last name");
		String b= sc.nextLine();
		Exercise4 s=new Exercise4();
		s.m1(a, b);
		sc.close();
		
	}
}