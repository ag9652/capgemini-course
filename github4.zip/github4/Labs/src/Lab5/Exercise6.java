package Lab5;
import java.util.Scanner;

class EmployeeException extends Exception {
	private int salary;
	public EmployeeException(int salary) {
		this.salary=salary;
		
	}
	@Override
	public String toString() {
		return "Salary is below than 3000";
	}
	
	
}
public class Exercise6 {
	static void Validatesalary(int salary) throws EmployeeException {
		if(salary <=3000)
		{
			throw new EmployeeException(salary);
		}
		else 
		{
			System.out.println("Your salary is more than 3000:");
		}
	}
	public static void main(String[] args) throws EmployeeException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Salary:");
		int salary=sc.nextInt();
		Exercise6.Validatesalary(salary);
		sc.close();
	}

}
