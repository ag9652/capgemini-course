package Lab1;

import java.util.Scanner;

public class Exercise2 {
	static int calculateDifference(int n) {
int sum=0,a=0,g,p=0,sq ;
{
for(int i=1;i<=n;i++) 
{
	 g=i*i;
	 a=a+g;
}
for(int j=1;j<=n;j++)
{
	 p=p+j;
	 
}
sq=p*p;
sum=a-sq;
return sum;
}
	}

public static void main(String args[])
{
	 Scanner s=new Scanner(System.in);
	 System.out.println("enter the num n:");
	 int n=s.nextInt();
	 int sum= calculateDifference(n);
	 System.out.println(sum);
	
}
}