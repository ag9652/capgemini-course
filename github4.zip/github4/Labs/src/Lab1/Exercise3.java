package Lab1;
import java.util.Scanner;

public class Exercise3 {
 static boolean checkNumber(int number)
 {
	 int t;
	 t=number;
	 while(number>0)
	 {
		 t=t/10;
		 	int a=number%10;
		 	number = number/10;
		 	int b=number%10;
		 	if(b>a) {
		 		return false;
		 	}
		 	return true;
	 }
	return false;
 }
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	int number = s.nextInt();
	Exercise3 k=new Exercise3();
	k.checkNumber(number);
	if(checkNumber(number))
	{
		System.out.println(" it is increasing");
	}
	else
	{
		System.out.println("it is not increasing");
	}
}
 
}
