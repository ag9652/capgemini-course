package Lab1;
import java.util.Scanner;
public class Exercise4 {
static boolean checkNumber(int n)
{
	while(n>1) {
		if(n%2!=0)
		{
			return false;
		}
		n=n/2;
	}
	return true;
}
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	System.out.println("enter  n");
	int n= s.nextInt();
	Exercise4 a= new Exercise4();
	a.checkNumber(n);
	if(checkNumber(n))
	{
		System.out.println(n+"is a power of 2");
	}
	else
	{
		System.out.println(n+"is not a power of 2");
	}
}
}
