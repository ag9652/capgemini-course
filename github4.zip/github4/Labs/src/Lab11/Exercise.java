package Lab11;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exercise {
	public static void main(String[] args) {
		ExecutorService service = Executors.newFixedThreadPool(5);
		for(int i = 0;i < 10;i++) {
			service.execute(new LabEx());
			System.out.println("Thread name :"+Thread.currentThread().getName()+" is running");
		}
	}
}

class LabEx implements Runnable{

	@Override
	public void run() {
		System.out.println("Thread name :"+Thread.currentThread().getName()+" is running");
	}
	
}