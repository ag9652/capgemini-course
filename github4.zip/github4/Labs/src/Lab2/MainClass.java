package Lab2;

public class MainClass {

	public static void main(String[] args) {
		//
		CD cd = new CD();
		cd.setArtist("Gopal");
		System.out.println(cd.getArtist());
		cd.setAuthor("new author");
		System.out.println(cd.getAuthor());
		
		

	}

}
