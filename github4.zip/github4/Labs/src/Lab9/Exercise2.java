package Lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

//Create a method that accepts a character array and count the number of times
//each character is present in the array. Add how many times each character is 
//present to a hash mapw ith the character as key and the repetitions count as value.

public class Exercise2 {
	private static Map countCharacter(char[] charArray) {
		
		HashMap<Character,Integer> myHashMap=new HashMap<Character,Integer>();
		
		for (char myChar:charArray)
		{
			if(myHashMap.containsKey(myChar))
			{
				myHashMap.replace(myChar,myHashMap.get(myChar)+1);
			}
			else 
			{
				myHashMap.putIfAbsent(myChar,1);
			}
		
		}
		return myHashMap;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Characters : ");
		String input=sc.nextLine();
		sc.close();
		char[] charArray=input.toCharArray();
		@SuppressWarnings("unchecked")
		HashMap<Character,Integer> myHashMap =(HashMap<Character,Integer>)Exercise2.countCharacter(charArray);
		System.out.println(myHashMap);	
	}
}