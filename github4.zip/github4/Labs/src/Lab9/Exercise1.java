package Lab9;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
//	Create a method which accepts a hash map and return the values
//	of the map in sorted order as a List.
	
	class myComparator implements Comparator 
	{
		public int compare(Object obj1, Object obj2)
		{
			Integer i1= (Integer) obj1;
			Integer i2= (Integer) obj2;
			return i1.compareTo(i2);
		}
	}
	public class Exercise1 {
		
	public static List getValues(HashMap myHashMap) {
		List myList=new ArrayList(myHashMap.values());
		myList.sort(new myComparator());
		return myList;
	}
		
	public static void main(String[] args) {
	
		HashMap myHashMap=new HashMap();
		myHashMap.put('a', 1);
		myHashMap.put('b', 2);
		myHashMap.put('c', 3);
		myHashMap.put('d', 4);
		myHashMap.put('e', 5);
		myHashMap.put('f', 6);
		
		System.out.println(Exercise1.getValues(myHashMap));
}
}