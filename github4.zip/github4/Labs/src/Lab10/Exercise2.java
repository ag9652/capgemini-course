package Lab10;

public class Exercise2 implements Runnable {
	
	public static long timer = 1;

	public void run() {
		try {
			while (true) {
				Thread.sleep(10000);
				System.out.println("Resetting timer.....");
				timer = 0;
			}
		} catch (InterruptedException e) {
			System.out.println("Stopped!");
		}

	}
	public static void main(String[] args) throws InterruptedException {

		Thread t = new Thread(new Exercise2());
		t.start();
		while (true)
		{
			System.out.println(timer);
			Thread.sleep(1000);
			timer++;
		}

	}

}