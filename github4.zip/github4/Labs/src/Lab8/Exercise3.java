package Lab8;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.*;
public class Exercise3 {
int wordcount=0;
int sentencecount=0;
int charactercount=0;
public void Read()throws IOException
{
	try {
		RandomAccessFile random =new RandomAccessFile("C:\\Users\\goallu\\Desktop\\corejava\\capg1.txt", "r");
		String a;
		
		while((a=random.readLine())!= null)
		{
			charactercount+=a.length();
			String[] Word = a.split("\\s+");
			wordcount+=Word.length;
			String[] sentence = a.split("[!?.:]+");
			sentencecount+=sentence.length;
		}
		System.out.println("TOTAL WORDCOUNT:"+wordcount);
		System.out.println("TOTAL SENTENCECOUNT:"+sentencecount);
		System.out.println("TOTAL CHARACTERCOUNT:"+charactercount);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
public static void main(String[] args) throws IOException {
	Exercise3 obj=new Exercise3();
	obj.Read();
}
}
