package Lab8;

import java.util.Scanner;
public class Exercise7 {

	public static boolean validate(String username)
	{
		String regex=".{8,}_job$";
		
		
		return username.matches(regex);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Username : ");
		String input=sc.nextLine();
		sc.close();
		System.out.println(Exercise7.validate(input));
}
}

