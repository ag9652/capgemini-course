package com.Lab8;
import java.util.*;
public class Exercise5 {

}
