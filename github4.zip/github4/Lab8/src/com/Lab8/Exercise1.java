package com.Lab8;
import java.util.*;
public class Exercise1 {
public static void main(String[] args) {
	int sum=0;
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the integers:");
	String a=sc.nextLine();
	sc.close();
	StringTokenizer st=new StringTokenizer(a," ");
	
	while(st.hasMoreTokens())
	{
		String temp=st.nextToken();
		System.out.println(temp);
		sum=sum+Integer.parseInt(temp);
		
	}
	System.out.println("sum is:"+sum);
}
}
